import { createServerFn } from "@tanstack/react-start";
import { generateText, generateObject } from "ai";
import { z } from "zod";
import { zodToJsonSchema } from "zod-to-json-schema";
import { createLovableAiGatewayProvider, DEFAULT_MODEL } from "./ai-gateway";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

async function verifyOwnership(accessToken: string, businessId: string) {
  const { data: userData, error: userErr } = await supabaseAdmin.auth.getUser(accessToken);
  if (userErr || !userData.user) throw new Error("Unauthorized");
  const { data: biz, error } = await supabaseAdmin
    .from("businesses")
    .select("*")
    .eq("id", businessId)
    .eq("owner_id", userData.user.id)
    .maybeSingle();
  if (error || !biz) throw new Error("Business not found");
  return { user: userData.user, business: biz };
}

function getModel() {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Missing LOVABLE_API_KEY");
  return createLovableAiGatewayProvider(key)(DEFAULT_MODEL);
}

// Robust JSON extraction for fallback when generateObject fails
function extractJson(text: string): unknown {
  let cleaned = text.replace(/```json\s*/gi, "").replace(/```\s*/g, "").trim();
  const start = cleaned.search(/[\{\[]/);
  if (start === -1) throw new Error("No JSON in response");
  const openChar = cleaned[start];
  const closeChar = openChar === "[" ? "]" : "}";
  const end = cleaned.lastIndexOf(closeChar);
  if (end === -1) throw new Error("Truncated JSON");
  cleaned = cleaned.slice(start, end + 1);
  try {
    return JSON.parse(cleaned);
  } catch {
    cleaned = cleaned.replace(/,\s*}/g, "}").replace(/,\s*]/g, "]").replace(/[\x00-\x1F\x7F]/g, " ");
    return JSON.parse(cleaned);
  }
}

async function structured<T>(schema: z.ZodType<T>, prompt: string): Promise<T> {
  const model = getModel();
  const jsonSchema = JSON.stringify(zodToJsonSchema(schema as z.ZodTypeAny), null, 2);
  const fullPrompt = `${prompt}

Return ONLY a single valid JSON value that strictly matches this JSON schema. No markdown, no commentary, no code fences, no explanations. Every required field MUST be present and use the EXACT key names from the schema. Do not invent extra fields.

JSON schema:
${jsonSchema}`;

  let lastErr: unknown = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const { text } = await generateText({ model, prompt: fullPrompt });
      const parsed = extractJson(text);
      return schema.parse(parsed);
    } catch (err) {
      lastErr = err;
      console.error(`[structured] attempt ${attempt + 1} failed:`, err);
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("Structured generation failed");
}

const TaskSchema = z.object({
  title: z.string(),
  why: z.string(),
  category: z.string(),
  priority: z.enum(["p1", "p2", "p3"]),
  impact_points: z.number().min(1).max(15),
  difficulty: z.number().min(1).max(3),
  est_minutes: z.number().min(5).max(120),
  tutorial_md: z.string(),
});

export const generateWeeklyTasks = createServerFn({ method: "POST" })
  .inputValidator((d: { accessToken: string; businessId: string; weakestFactors: string[] }) => d)
  .handler(async ({ data }) => {
    const { business } = await verifyOwnership(data.accessToken, data.businessId);

    const prompt = `You are a local SEO coach. Generate exactly 6 weekly action tasks for this local business.

Business: ${business.name} (${business.category}) in ${business.city}, ${business.country}
Snapshot: ${business.review_count} reviews at ${business.avg_rating} stars, ${business.photo_count} photos, posts ${business.posting_freq}.
Weakest score factors: ${data.weakestFactors.join(", ") || "general visibility"}.
Goals: ${JSON.stringify(business.goals)}.

Tasks must be:
- specific to the business (use its name, city, category)
- beginner-friendly: under 30 min each
- include 1 P1 review-related task, 1 P1 photo or post task, plus 4 supporting tasks
- tutorial_md: 3 to 6 short numbered markdown steps

Return JSON with shape: { "tasks": [ ... 6 tasks ... ] }.`;

    const out = await structured(z.object({ tasks: z.array(TaskSchema).min(4).max(8) }), prompt);

    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - weekStart.getDay() + 1);
    const weekStartStr = weekStart.toISOString().slice(0, 10);

    const rows = out.tasks.slice(0, 6).map((t) => ({
      business_id: business.id,
      week_start: weekStartStr,
      title: t.title,
      why: t.why,
      category: t.category,
      priority: t.priority,
      impact_points: t.impact_points,
      difficulty: t.difficulty,
      est_minutes: t.est_minutes,
      tutorial_md: t.tutorial_md,
      xp_awarded: t.priority === "p1" ? 100 : t.priority === "p2" ? 60 : 40,
    }));

    const { error } = await supabaseAdmin.from("tasks").insert(rows);
    if (error) throw new Error(error.message);

    return { count: rows.length };
  });

export const generateGbpContent = createServerFn({ method: "POST" })
  .inputValidator(
    (d: {
      accessToken: string;
      businessId: string;
      kind: "post" | "description" | "faq" | "service";
      tone: "friendly" | "professional" | "bold";
      topic?: string;
    }) => d,
  )
  .handler(async ({ data }) => {
    const { business } = await verifyOwnership(data.accessToken, data.businessId);
    const model = getModel();

    const tonePrompt: Record<string, string> = {
      friendly: "warm, approachable, casual",
      professional: "polished, expert, trustworthy",
      bold: "confident, energetic, action-driving",
    };

    const kindPrompt: Record<string, string> = {
      post: `Write 4 Google Business Profile posts (each 80 to 120 words). Each should highlight a different angle: offer, tip, behind-the-scenes, customer story. Format as: ### Post 1\n<text>\n\n### Post 2 ...`,
      description: `Write a 600 to 700 character GBP business description, keyword-rich for "${business.category} ${business.city}", first-person, ending with a clear CTA.`,
      faq: `Write 8 FAQs (Q + A) people ask before booking a ${business.category} in ${business.city}. Format as ### Q: question\n A: answer.`,
      service: `Write 6 service descriptions (60 to 100 words each) for typical ${business.category} services. Format ### Service Name\n<description>.`,
    };

    const prompt = `Tone: ${tonePrompt[data.tone]}.
Business: ${business.name}, a ${business.category} in ${business.city}, ${business.country}.
${data.topic ? `Topic focus: ${data.topic}.` : ""}

${kindPrompt[data.kind]}

Use natural local keywords. Avoid clichés.`;

    const { text } = await generateText({ model, prompt });

    await supabaseAdmin.from("ai_generations").insert({
      business_id: business.id,
      kind: `gbp_${data.kind}`,
      input: { tone: data.tone, topic: data.topic ?? null },
      output: text,
    });

    return { text };
  });

const CompetitorSchema = z.object({
  competitors: z
    .array(
      z.object({
        name: z.string(),
        strengths: z.array(z.string()).min(1).max(5),
        weaknesses: z.array(z.string()).min(1).max(5),
        opportunities_for_you: z.array(z.string()).min(1).max(5),
        estimated_review_count: z.number(),
        estimated_rating: z.number(),
        threat_level: z.enum(["low", "medium", "high"]),
      }),
    )
    .min(3)
    .max(6),
  positioning_summary: z.string(),
  three_quick_wins: z.array(z.string()).min(2).max(5),
});

export const analyzeCompetitors = createServerFn({ method: "POST" })
  .inputValidator((d: { accessToken: string; businessId: string; competitorNames?: string[] }) => d)
  .handler(async ({ data }) => {
    const { business } = await verifyOwnership(data.accessToken, data.businessId);

    const prompt = `You are a local SEO analyst. Analyze the competitive landscape for this business and ${data.competitorNames?.length ? `the following named competitors: ${data.competitorNames.join(", ")}.` : `infer 4 likely top competitors operating in the same city and category.`}

Business: ${business.name}, a ${business.category} in ${business.city}, ${business.country}.
Current snapshot: ${business.review_count} reviews at ${business.avg_rating} stars, ${business.photo_count} photos.

For each competitor return realistic estimated review counts and ratings. Be specific.`;

    const out = await structured(CompetitorSchema, prompt);

    await supabaseAdmin.from("ai_generations").insert({
      business_id: business.id,
      kind: "competitor_analysis",
      input: { competitorNames: data.competitorNames ?? [] },
      output: JSON.stringify(out),
    });

    return out;
  });

const RankingSchema = z.object({
  keywords: z
    .array(
      z.object({
        keyword: z.string(),
        estimated_rank: z.number().min(1).max(100),
        search_volume_band: z.enum(["low", "medium", "high"]),
        difficulty: z.enum(["easy", "moderate", "hard"]),
        intent: z.enum(["informational", "commercial", "transactional", "navigational"]),
        why_this_rank: z.string(),
        action_to_improve: z.string(),
      }),
    )
    .min(6)
    .max(14),
  overall_visibility: z.number().min(0).max(100),
  top_priority_keyword: z.string(),
});

export const estimateRankings = createServerFn({ method: "POST" })
  .inputValidator((d: { accessToken: string; businessId: string; extraKeywords?: string[] }) => d)
  .handler(async ({ data }) => {
    const { business } = await verifyOwnership(data.accessToken, data.businessId);

    const prompt = `You are a local SEO ranking analyst. Estimate Google Maps and local SERP rankings for this business across 10 high-intent local keywords.

Business: ${business.name} (${business.category}) in ${business.city}, ${business.country}.
Snapshot: ${business.review_count} reviews at ${business.avg_rating} stars, ${business.photo_count} photos, posts ${business.posting_freq}, description present: ${!!business.description}.
${data.extraKeywords?.length ? `Also include these keywords: ${data.extraKeywords.join(", ")}.` : ""}

Generate a realistic mix of branded, service plus city, "near me", and modifier keywords. Be honest about ranks.`;

    const out = await structured(RankingSchema, prompt);

    await supabaseAdmin.from("ai_generations").insert({
      business_id: business.id,
      kind: "ranking_estimate",
      input: { extraKeywords: data.extraKeywords ?? [] },
      output: JSON.stringify(out),
    });

    return out;
  });

const ContentSchema = z.object({
  title: z.string(),
  meta_description: z.string(),
  outline: z.array(z.string()).min(3).max(10),
  body_markdown: z.string(),
  social_caption: z.string(),
  email_subject: z.string(),
});

export const generateMarketingContent = createServerFn({ method: "POST" })
  .inputValidator(
    (d: {
      accessToken: string;
      businessId: string;
      kind: "blog" | "landing" | "email" | "social";
      topic: string;
      tone: "friendly" | "professional" | "bold";
    }) => d,
  )
  .handler(async ({ data }) => {
    const { business } = await verifyOwnership(data.accessToken, data.businessId);

    const kindMap: Record<string, string> = {
      blog: "an 800 word SEO blog article optimized for local intent",
      landing: "a high converting landing page with hero, three benefits, social proof block, and CTA",
      email: "a 250 word marketing email to past customers",
      social: "a 5 post Instagram or Facebook content week with captions and hashtags",
    };

    const prompt = `You are a senior marketing copywriter. Write ${kindMap[data.kind]} for ${business.name}, a ${business.category} in ${business.city}, ${business.country}.

Topic: ${data.topic}
Tone: ${data.tone}.

Use natural local keywords. Use real, vivid copy.`;

    const out = await structured(ContentSchema, prompt);

    await supabaseAdmin.from("ai_generations").insert({
      business_id: business.id,
      kind: `marketing_${data.kind}`,
      input: { topic: data.topic, tone: data.tone },
      output: JSON.stringify(out),
    });

    return out;
  });

const ReportSchema = z.object({
  executive_summary: z.string(),
  growth_score_commentary: z.string(),
  what_went_well: z.array(z.string()).min(2).max(6),
  what_to_fix: z.array(z.string()).min(2).max(6),
  next_30_days_plan: z
    .array(
      z.object({
        week: z.number().min(1).max(4),
        focus: z.string(),
        actions: z.array(z.string()).min(1).max(5),
      }),
    )
    .min(3)
    .max(5),
  expected_impact: z.string(),
});

export const generateReport = createServerFn({ method: "POST" })
  .inputValidator((d: { accessToken: string; businessId: string }) => d)
  .handler(async ({ data }) => {
    const { business } = await verifyOwnership(data.accessToken, data.businessId);

    const prompt = `Write a professional monthly local SEO report for ${business.name}, a ${business.category} in ${business.city}.
Snapshot: score ${business.current_score} of 100, ${business.review_count} reviews at ${business.avg_rating} stars, ${business.photo_count} photos, posts ${business.posting_freq}, XP ${business.xp}, streak ${business.streak_days} days.

Tone: confident, encouraging, written for the owner. No jargon. Each plan week must have a clear focus and 1 to 4 concrete actions.`;

    const out = await structured(ReportSchema, prompt);

    await supabaseAdmin.from("ai_generations").insert({
      business_id: business.id,
      kind: "monthly_report",
      input: {},
      output: JSON.stringify(out),
    });

    return out;
  });

export const generateReviewReply = createServerFn({ method: "POST" })
  .inputValidator(
    (d: {
      accessToken: string;
      businessId: string;
      reviewText: string;
      rating: number;
      tone: "friendly" | "professional" | "bold";
    }) => d,
  )
  .handler(async ({ data }) => {
    const { business } = await verifyOwnership(data.accessToken, data.businessId);
    const model = getModel();

    const isNegative = data.rating <= 3;
    const prompt = `You are replying as the owner of ${business.name} (${business.category}, ${business.city}) to a Google review.

Review (${data.rating} stars): "${data.reviewText}"

Tone: ${data.tone}.
${isNegative ? "This is a critical review. De-escalate, take ownership, invite offline conversation, do NOT be defensive." : "Thank them sincerely, mention a specific detail, invite them back."}

Generate 3 reply variants. Each 50 to 90 words. Format strictly:

### Variant 1
<reply>

### Variant 2
<reply>

### Variant 3
<reply>`;

    const { text } = await generateText({ model, prompt });

    await supabaseAdmin.from("ai_generations").insert({
      business_id: business.id,
      kind: "review_reply",
      input: { rating: data.rating, tone: data.tone, review: data.reviewText },
      output: text,
    });

    return { text };
  });
