// Deterministic local Growth Score (0–100). Pure function — usable client or server.

export type BusinessSnapshot = {
  review_count: number;
  avg_rating: number;
  photo_count: number;
  posting_freq: string; // never|monthly|weekly|daily
  description: string | null;
  website: string | null;
  gbp_url: string | null;
  services: unknown[];
  city: string | null;
};

export type ScoreFactor = {
  key: string;
  label: string;
  weight: number;
  earned: number; // 0..weight
  detail: string;
};

export function computeScore(b: BusinessSnapshot): { score: number; factors: ScoreFactor[] } {
  const factors: ScoreFactor[] = [];

  // Reviews count (15)
  const rcEarned = Math.round(Math.min(1, b.review_count / 100) * 15);
  factors.push({
    key: "reviews",
    label: "Review count",
    weight: 15,
    earned: rcEarned,
    detail: `${b.review_count} reviews — top businesses have 100+`,
  });

  // Avg rating (15) — 4.0 = 50%, 5.0 = 100%
  const ratingPct = Math.max(0, Math.min(1, (Number(b.avg_rating) - 3) / 2));
  factors.push({
    key: "rating",
    label: "Average rating",
    weight: 15,
    earned: Math.round(ratingPct * 15),
    detail: `${Number(b.avg_rating).toFixed(1)}★ — aim for 4.7+`,
  });

  // Photos (10) — 50 photos full
  factors.push({
    key: "photos",
    label: "Photo library",
    weight: 10,
    earned: Math.round(Math.min(1, b.photo_count / 50) * 10),
    detail: `${b.photo_count} photos — target 50+`,
  });

  // Posting frequency (10)
  const postMap: Record<string, number> = { never: 0, monthly: 4, weekly: 8, daily: 10 };
  factors.push({
    key: "posts",
    label: "Posting frequency",
    weight: 10,
    earned: postMap[b.posting_freq] ?? 0,
    detail: `Posts ${b.posting_freq} — weekly is the sweet spot`,
  });

  // Profile completeness (15) — check fields
  let comp = 0;
  if (b.description && b.description.length > 80) comp += 5;
  if (b.website) comp += 4;
  if (b.gbp_url) comp += 3;
  if (Array.isArray(b.services) && b.services.length >= 3) comp += 3;
  factors.push({
    key: "completeness",
    label: "Profile completeness",
    weight: 15,
    earned: comp,
    detail: `${comp}/15 — fill description, website, GBP, services`,
  });

  // Service / keyword coverage (10)
  const svcCount = Array.isArray(b.services) ? b.services.length : 0;
  factors.push({
    key: "services",
    label: "Service coverage",
    weight: 10,
    earned: Math.round(Math.min(1, svcCount / 8) * 10),
    detail: `${svcCount} services listed — aim for 8+`,
  });

  // Website presence (10)
  factors.push({
    key: "website",
    label: "Website presence",
    weight: 10,
    earned: b.website ? 10 : 0,
    detail: b.website ? "Website connected" : "No website linked yet",
  });

  // NAP consistency self-reported (5) — assume 3 if GBP exists
  factors.push({
    key: "nap",
    label: "NAP consistency",
    weight: 5,
    earned: b.gbp_url ? 4 : 1,
    detail: "Name, Address, Phone matching across the web",
  });

  // Description quality (10) — length-based heuristic
  const descLen = b.description?.length ?? 0;
  const descScore = descLen > 500 ? 10 : descLen > 250 ? 7 : descLen > 100 ? 4 : descLen > 0 ? 2 : 0;
  factors.push({
    key: "description",
    label: "Business description",
    weight: 10,
    earned: descScore,
    detail: descLen > 0 ? `${descLen} chars — keyword-rich descriptions help ranking` : "Add a 250+ char description",
  });

  const score = factors.reduce((s, f) => s + f.earned, 0);
  return { score: Math.max(0, Math.min(100, score)), factors };
}

export function levelFromXp(xp: number) {
  const level = Math.floor(xp / 500) + 1;
  const into = xp % 500;
  return { level, into, next: 500, pct: Math.round((into / 500) * 100) };
}
