import { useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, Sparkles, Flame, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { SidebarNav } from "./SidebarNav";
import type { Business } from "@/hooks/useBusiness";
import { levelFromXp } from "@/lib/scoring";

export function AppShell({ business, children }: { business: Business; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const lvl = levelFromXp(business.xp);

  return (
    <div className="flex min-h-screen w-full bg-background">
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r bg-sidebar lg:flex">
        <Link to="/app" className="flex items-center gap-2 px-5 py-5">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground shadow-md">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <div className="font-display text-base font-bold leading-tight">Local Growth OS</div>
            <div className="text-[11px] text-muted-foreground">Your local-SEO coach</div>
          </div>
        </Link>
        <div className="flex-1 overflow-y-auto">
          <SidebarNav />
        </div>
      </aside>

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur lg:px-8">
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0">
              <Link to="/app" className="flex items-center gap-2 px-5 py-5" onClick={() => setOpen(false)}>
                <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground">
                  <Sparkles className="h-5 w-5" />
                </div>
                <div className="font-display font-bold">Local Growth OS</div>
              </Link>
              <SidebarNav onNavigate={() => setOpen(false)} />
            </SheetContent>
          </Sheet>

          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-semibold">{business.name}</div>
            <div className="truncate text-xs text-muted-foreground">
              {business.category} · {business.city}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-1.5 rounded-full bg-accent/15 px-3 py-1.5 text-xs font-semibold text-accent-foreground sm:flex">
              <Flame className="h-3.5 w-3.5 text-accent" />
              {business.streak_days} day streak
            </div>
            <div className="flex items-center gap-1.5 rounded-full bg-primary/15 px-3 py-1.5 text-xs font-semibold text-primary-foreground/80">
              <Zap className="h-3.5 w-3.5 text-primary" />
              Lv {lvl.level} · {business.xp} XP
            </div>
          </div>
        </header>

        <main className="min-w-0 flex-1 px-4 py-6 lg:px-8 lg:py-8">{children}</main>
      </div>
    </div>
  );
}
