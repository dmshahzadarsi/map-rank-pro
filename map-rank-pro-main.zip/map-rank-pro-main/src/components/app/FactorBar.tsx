import type { ScoreFactor } from "@/lib/scoring";

export function FactorBar({ factor }: { factor: ScoreFactor }) {
  const pct = Math.round((factor.earned / factor.weight) * 100);
  const color =
    pct >= 80 ? "bg-success" : pct >= 50 ? "bg-accent" : "bg-destructive";
  return (
    <div className="rounded-2xl border bg-card p-4">
      <div className="flex items-baseline justify-between gap-3">
        <div className="font-semibold">{factor.label}</div>
        <div className="text-sm tabular-nums text-muted-foreground">
          <span className="text-foreground font-bold">{factor.earned}</span>
          <span className="text-muted-foreground">/{factor.weight}</span>
        </div>
      </div>
      <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-secondary">
        <div className={`h-full rounded-full ${color} transition-all`} style={{ width: `${pct}%` }} />
      </div>
      <div className="mt-2 text-xs text-muted-foreground">{factor.detail}</div>
    </div>
  );
}
