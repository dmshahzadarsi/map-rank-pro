import { Link, useLocation } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Gauge,
  ListChecks,
  Building2,
  Star,
  MessageCircle,
  Settings,
  Trophy,
  TrendingUp,
  Globe,
  GraduationCap,
  FileText,
  Wand2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

const items = [
  { to: "/app", icon: LayoutDashboard, label: "Overview" },
  { to: "/app/score", icon: Gauge, label: "Growth Score" },
  { to: "/app/tasks", icon: ListChecks, label: "Weekly Tasks" },
  { to: "/app/gbp", icon: Building2, label: "Google Profile" },
  { to: "/app/reviews", icon: Star, label: "Reviews" },
  { to: "/app/coach", icon: MessageCircle, label: "AI Coach" },
];

const growth = [
  { to: "/app/competitors", icon: Trophy, label: "Competitors" },
  { to: "/app/rankings", icon: TrendingUp, label: "Rankings" },
  { to: "/app/citations", icon: Globe, label: "Citations" },
  { to: "/app/ai-content", icon: Wand2, label: "AI Content" },
  { to: "/app/reports", icon: FileText, label: "Reports" },
  { to: "/app/academy", icon: GraduationCap, label: "Academy" },
];

export function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  const { pathname } = useLocation();

  const renderLink = (item: { to: string; icon: any; label: string }) => {
    const active = pathname === item.to || (item.to !== "/app" && pathname.startsWith(item.to));
    return (
      <Link
        key={item.to}
        to={item.to}
        onClick={onNavigate}
        className={cn(
          "flex items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition-all",
          active
            ? "bg-primary text-primary-foreground shadow-sm"
            : "text-foreground/80 hover:bg-secondary hover:text-foreground",
        )}
      >
        <item.icon className="h-4 w-4" />
        {item.label}
      </Link>
    );
  };

  return (
    <nav className="flex flex-col gap-1 p-3 text-sm">
      <div className="px-3 pb-2 pt-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        Workspace
      </div>
      {items.map(renderLink)}

      <div className="px-3 pb-2 pt-5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        Growth tools
      </div>
      {growth.map(renderLink)}

      <Link
        to="/app/settings"
        onClick={onNavigate}
        className={cn(
          "mt-6 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium",
          pathname === "/app/settings"
            ? "bg-secondary text-foreground"
            : "text-foreground/80 hover:bg-secondary",
        )}
      >
        <Settings className="h-4 w-4" />
        Settings
      </Link>

      <div className="mx-3 mt-4 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 to-accent/10 p-3">
        <Badge className="bg-accent text-accent-foreground">Beta</Badge>
        <p className="mt-2 text-xs text-foreground/80">
          You are in early access. New modules ship every week.
        </p>
      </div>
    </nav>
  );
}
