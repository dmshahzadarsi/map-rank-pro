export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_generations: {
        Row: {
          business_id: string
          created_at: string
          id: string
          input: Json
          kind: string
          output: string
        }
        Insert: {
          business_id: string
          created_at?: string
          id?: string
          input?: Json
          kind: string
          output: string
        }
        Update: {
          business_id?: string
          created_at?: string
          id?: string
          input?: Json
          kind?: string
          output?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_generations_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      badges: {
        Row: {
          business_id: string
          code: string
          earned_at: string
          id: string
        }
        Insert: {
          business_id: string
          code: string
          earned_at?: string
          id?: string
        }
        Update: {
          business_id?: string
          code?: string
          earned_at?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "badges_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      businesses: {
        Row: {
          avg_rating: number
          category: string
          city: string
          country: string
          created_at: string
          current_score: number
          description: string | null
          gbp_url: string | null
          goals: Json
          id: string
          last_active_date: string | null
          name: string
          owner_id: string
          photo_count: number
          posting_freq: string
          review_count: number
          service_area: string | null
          services: Json
          streak_days: number
          updated_at: string
          website: string | null
          xp: number
          years_in_business: number
        }
        Insert: {
          avg_rating?: number
          category: string
          city: string
          country: string
          created_at?: string
          current_score?: number
          description?: string | null
          gbp_url?: string | null
          goals?: Json
          id?: string
          last_active_date?: string | null
          name: string
          owner_id: string
          photo_count?: number
          posting_freq?: string
          review_count?: number
          service_area?: string | null
          services?: Json
          streak_days?: number
          updated_at?: string
          website?: string | null
          xp?: number
          years_in_business?: number
        }
        Update: {
          avg_rating?: number
          category?: string
          city?: string
          country?: string
          created_at?: string
          current_score?: number
          description?: string | null
          gbp_url?: string | null
          goals?: Json
          id?: string
          last_active_date?: string | null
          name?: string
          owner_id?: string
          photo_count?: number
          posting_freq?: string
          review_count?: number
          service_area?: string | null
          services?: Json
          streak_days?: number
          updated_at?: string
          website?: string | null
          xp?: number
          years_in_business?: number
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          business_id: string
          content: string
          created_at: string
          id: string
          parts: Json | null
          role: string
        }
        Insert: {
          business_id: string
          content: string
          created_at?: string
          id?: string
          parts?: Json | null
          role: string
        }
        Update: {
          business_id?: string
          content?: string
          created_at?: string
          id?: string
          parts?: Json | null
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      gbp_checklist: {
        Row: {
          business_id: string
          done: boolean
          id: string
          item_key: string
          updated_at: string
        }
        Insert: {
          business_id: string
          done?: boolean
          id?: string
          item_key: string
          updated_at?: string
        }
        Update: {
          business_id?: string
          done?: boolean
          id?: string
          item_key?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "gbp_checklist_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string | null
          id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
        }
        Relationships: []
      }
      review_entries: {
        Row: {
          business_id: string
          created_at: string
          customer_name: string | null
          id: string
          rating: number
          replied: boolean
          reply_text: string | null
          text: string | null
        }
        Insert: {
          business_id: string
          created_at?: string
          customer_name?: string | null
          id?: string
          rating: number
          replied?: boolean
          reply_text?: string | null
          text?: string | null
        }
        Update: {
          business_id?: string
          created_at?: string
          customer_name?: string | null
          id?: string
          rating?: number
          replied?: boolean
          reply_text?: string | null
          text?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "review_entries_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      score_snapshots: {
        Row: {
          business_id: string
          created_at: string
          factors: Json
          id: string
          score: number
        }
        Insert: {
          business_id: string
          created_at?: string
          factors: Json
          id?: string
          score: number
        }
        Update: {
          business_id?: string
          created_at?: string
          factors?: Json
          id?: string
          score?: number
        }
        Relationships: [
          {
            foreignKeyName: "score_snapshots_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      tasks: {
        Row: {
          business_id: string
          category: string
          completed_at: string | null
          created_at: string
          difficulty: number
          est_minutes: number
          id: string
          impact_points: number
          priority: Database["public"]["Enums"]["task_priority"]
          status: Database["public"]["Enums"]["task_status"]
          title: string
          tutorial_md: string
          week_start: string
          why: string
          xp_awarded: number
        }
        Insert: {
          business_id: string
          category: string
          completed_at?: string | null
          created_at?: string
          difficulty?: number
          est_minutes?: number
          id?: string
          impact_points?: number
          priority?: Database["public"]["Enums"]["task_priority"]
          status?: Database["public"]["Enums"]["task_status"]
          title: string
          tutorial_md?: string
          week_start: string
          why: string
          xp_awarded?: number
        }
        Update: {
          business_id?: string
          category?: string
          completed_at?: string | null
          created_at?: string
          difficulty?: number
          est_minutes?: number
          id?: string
          impact_points?: number
          priority?: Database["public"]["Enums"]["task_priority"]
          status?: Database["public"]["Enums"]["task_status"]
          title?: string
          tutorial_md?: string
          week_start?: string
          why?: string
          xp_awarded?: number
        }
        Relationships: [
          {
            foreignKeyName: "tasks_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      xp_events: {
        Row: {
          amount: number
          business_id: string
          created_at: string
          id: string
          source: string
        }
        Insert: {
          amount: number
          business_id: string
          created_at?: string
          id?: string
          source: string
        }
        Update: {
          amount?: number
          business_id?: string
          created_at?: string
          id?: string
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "xp_events_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      owns_business: { Args: { _business_id: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "user"
      task_priority: "p1" | "p2" | "p3"
      task_status: "open" | "done" | "skipped"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
      task_priority: ["p1", "p2", "p3"],
      task_status: ["open", "done", "skipped"],
    },
  },
} as const
