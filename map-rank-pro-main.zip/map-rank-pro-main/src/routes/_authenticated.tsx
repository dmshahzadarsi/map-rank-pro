import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { useAuth } from "@/hooks/useAuth";
import { Sparkles } from "lucide-react";

export const Route = createFileRoute("/_authenticated")({
  component: AuthGate,
});

function AuthGate() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center bg-background">
        <div className="flex items-center gap-3 text-muted-foreground">
          <Sparkles className="h-5 w-5 animate-pulse text-primary" />
          Loading…
        </div>
      </div>
    );
  }

  if (!user) {
    // client-side redirect
    if (typeof window !== "undefined") {
      window.location.href = "/login";
    }
    return null;
  }

  return <Outlet />;
}

// Suppress unused import warning
void redirect;
