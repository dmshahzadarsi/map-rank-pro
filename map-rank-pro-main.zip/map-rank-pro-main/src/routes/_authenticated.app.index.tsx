import { createFileRoute, Link } from "@tanstack/react-router";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ScoreRing } from "@/components/app/ScoreRing";
import { computeScore, levelFromXp } from "@/lib/scoring";
import { ArrowRight, ListChecks, Star, Building2, MessageCircle, Flame, Zap, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/app/")({
  head: () => ({ meta: [{ title: "Overview, Local Growth OS" }] }),
  component: Overview,
});

function Overview() {
  const { user } = useAuth();
  const { data: business } = useMyBusiness(user?.id);

  const { data: openTasks } = useQuery({
    queryKey: ["tasks-open", business?.id],
    enabled: !!business?.id,
    queryFn: async () => {
      const { data } = await supabase.from("tasks").select("*").eq("business_id", business!.id).eq("status", "open").order("priority").limit(3);
      return data ?? [];
    },
  });

  if (!business) return null;
  const { score } = computeScore({
    review_count: business.review_count,
    avg_rating: Number(business.avg_rating),
    photo_count: business.photo_count,
    posting_freq: business.posting_freq,
    description: business.description,
    website: business.website,
    gbp_url: business.gbp_url,
    services: (business.services as unknown[]) ?? [],
    city: business.city,
  });
  const lvl = levelFromXp(business.xp);

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Overview</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">
          Hey there 👋 Let's grow {business.name}.
        </h1>
      </div>

      <div className="grid gap-5 lg:grid-cols-[auto_1fr]">
        <div className="rounded-3xl border bg-card p-6 grid place-items-center">
          <ScoreRing score={score} />
          <Button asChild variant="link" className="mt-2 text-sm">
            <Link to="/app/score">See breakdown <ArrowRight className="ml-1 h-3 w-3" /></Link>
          </Button>
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <Stat icon={Flame} label="Streak" value={`${business.streak_days} days`} hint="Show up weekly" tone="accent" />
          <Stat icon={Zap} label="Level" value={`Lv ${lvl.level}`} hint={`${lvl.into}/500 XP`} tone="primary" />
          <Stat icon={Trophy} label="XP earned" value={`${business.xp}`} hint="Complete tasks for more" tone="primary" />

          <div className="sm:col-span-3 rounded-3xl border bg-gradient-to-br from-primary/10 to-accent/10 p-5">
            <div className="text-xs font-bold uppercase tracking-wider text-primary">This week's focus</div>
            <h3 className="mt-1 font-display text-xl font-bold">
              {openTasks && openTasks.length > 0
                ? `${openTasks.length} open task${openTasks.length === 1 ? "" : "s"} ready to crush`
                : "Generate your weekly plan"}
            </h3>
            <Button asChild className="mt-4 rounded-full">
              <Link to="/app/tasks">Go to tasks <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <ModuleLink to="/app/tasks" icon={ListChecks} title="Weekly Tasks" desc="Your action plan" />
        <ModuleLink to="/app/gbp" icon={Building2} title="Google Profile" desc="Optimize your GBP" />
        <ModuleLink to="/app/reviews" icon={Star} title="Reviews" desc="Get more 5-stars" />
        <ModuleLink to="/app/coach" icon={MessageCircle} title="AI Coach" desc="Ask anything" />
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value, hint, tone }: { icon: any; label: string; value: string; hint: string; tone: "primary" | "accent" }) {
  return (
    <div className="rounded-3xl border bg-card p-5">
      <div className={`grid h-9 w-9 place-items-center rounded-xl ${tone === "primary" ? "bg-primary/15 text-primary" : "bg-accent/15 text-accent"}`}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="mt-3 text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-display text-2xl font-extrabold">{value}</div>
      <div className="text-xs text-muted-foreground">{hint}</div>
    </div>
  );
}

function ModuleLink({ to, icon: Icon, title, desc }: { to: string; icon: any; title: string; desc: string }) {
  return (
    <Link to={to} className="group rounded-2xl border bg-card p-5 transition hover:-translate-y-0.5 hover:shadow-md">
      <Icon className="h-5 w-5 text-primary" />
      <div className="mt-3 font-semibold">{title}</div>
      <div className="text-xs text-muted-foreground">{desc}</div>
    </Link>
  );
}
