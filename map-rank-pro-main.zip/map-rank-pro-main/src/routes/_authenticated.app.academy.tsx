import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { GraduationCap, Clock, Check, BookOpen, ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/app/academy")({
  head: () => ({ meta: [{ title: "Academy · Local Growth OS" }] }),
  component: AcademyPage,
});

type Lesson = {
  id: string;
  module: string;
  title: string;
  minutes: number;
  level: "beginner" | "intermediate" | "advanced";
  summary: string;
  steps: string[];
};

const LESSONS: Lesson[] = [
  {
    id: "gbp-101",
    module: "Foundations",
    title: "Google Business Profile in 10 minutes",
    minutes: 10,
    level: "beginner",
    summary: "Claim it, complete every field, and avoid the rookie mistakes that hide your business from local searchers.",
    steps: [
      "Sign in at business.google.com with the email you want to own the listing forever.",
      "Pick the most specific primary category, then add 2 to 4 secondary categories.",
      "Fill in services, hours, and a 600 to 750 character description with your city naturally.",
      "Upload at least 10 photos: exterior, interior, team, work in progress, and finished results.",
      "Add a booking or contact link so customers can act in one tap.",
    ],
  },
  {
    id: "reviews-flywheel",
    module: "Reputation",
    title: "Build a steady review flywheel",
    minutes: 12,
    level: "beginner",
    summary: "Most owners ask for reviews once, then forget. Here is the simple loop that compounds month after month.",
    steps: [
      "Pick the moment of peak happiness in your service: right after delivery, checkout, or success.",
      "Use a single short link from your Google Business Profile share menu.",
      "Send a friendly WhatsApp or SMS within 30 minutes of that peak moment.",
      "Reply to every review inside 48 hours, even the simple 5 star ones.",
      "Print a branded QR card for the front desk so walk ins can leave a review on the spot.",
    ],
  },
  {
    id: "photos-rank",
    module: "GBP optimization",
    title: "Why photos move you up the map",
    minutes: 8,
    level: "beginner",
    summary: "Listings with 100+ photos get many more clicks. Use this checklist to plan a 30 day photo sprint.",
    steps: [
      "Aim for one fresh photo every working day for 30 days.",
      "Mix the categories: team, work, interior, exterior, customer moments.",
      "Use natural daylight when possible. Phones beat fancy cameras on speed.",
      "Geotag is automatic when you upload from a phone in your service area.",
      "Caption every photo in plain language, including the city name.",
    ],
  },
  {
    id: "local-keywords",
    module: "SEO",
    title: "Find the keywords your customers actually type",
    minutes: 15,
    level: "intermediate",
    summary: "Stop guessing. Use Google itself to discover the exact phrases that bring buyers to your door.",
    steps: [
      "Open Google in incognito mode and start typing your service plus your city.",
      "Note every autocomplete suggestion. These are real searches.",
      "Scroll to People also ask and the related searches at the bottom.",
      "Group what you find into three buckets: branded, service plus city, and questions.",
      "Sprinkle these naturally into your GBP description, services, and website pages.",
    ],
  },
  {
    id: "post-cadence",
    module: "GBP optimization",
    title: "Posting cadence that Google rewards",
    minutes: 7,
    level: "beginner",
    summary: "You do not need viral content. You need a quiet, consistent drumbeat.",
    steps: [
      "Publish one Google Business post every 7 days minimum.",
      "Rotate four post types: offer, tip, behind the scenes, customer story.",
      "Always include one photo and one clear call to action button.",
      "Keep each post 80 to 120 words, with your city named once.",
      "Schedule 4 posts at the start of the month so you never miss a week.",
    ],
  },
  {
    id: "citations-101",
    module: "Foundations",
    title: "Citations explained without jargon",
    minutes: 9,
    level: "beginner",
    summary: "A citation is just a mention of your business name and contact info on another site. Here is what matters.",
    steps: [
      "Use one exact spelling of your business name everywhere. No abbreviations.",
      "Use the same address format on every directory.",
      "Start with the 8 core directories before chasing niche ones.",
      "Audit yourself yearly by Googling your business name in quotes.",
      "Update everywhere when you move, change phone, or refresh your logo.",
    ],
  },
  {
    id: "reply-negative",
    module: "Reputation",
    title: "Reply to a bad review without making it worse",
    minutes: 11,
    level: "intermediate",
    summary: "A calm, public reply turns a 1 star into proof that you care. Here is the script.",
    steps: [
      "Wait 1 hour before writing. Cool head, better words.",
      "Open with the customer's first name and a sincere thanks for the feedback.",
      "Acknowledge the specific issue without admitting fault publicly.",
      "Move the conversation off Google: invite a phone call or email.",
      "Close warmly. Future readers care more about your reply than the original review.",
    ],
  },
  {
    id: "competitor-spy",
    module: "SEO",
    title: "Steal smart from your top 3 competitors",
    minutes: 14,
    level: "advanced",
    summary: "Reverse engineer what is working for the businesses ranking above you, ethically.",
    steps: [
      "Search your top keyword in Google Maps and list the top 3 results.",
      "Audit each: review count, rating, photo count, last post date, services listed.",
      "Note one thing each does that you do not. Add it to your weekly tasks.",
      "Read their last 20 reviews and look for repeated praise. Mirror those strengths.",
      "Set a calendar reminder to repeat this every 90 days.",
    ],
  },
];

const MODULES = ["Foundations", "GBP optimization", "Reputation", "SEO"] as const;

function AcademyPage() {
  const [done, setDone] = useState<Record<string, boolean>>({});
  const [activeModule, setActiveModule] = useState<(typeof MODULES)[number] | "All">("All");
  const completed = Object.values(done).filter(Boolean).length;
  const totalMinutes = LESSONS.reduce((s, l) => s + l.minutes, 0);

  const filtered = activeModule === "All" ? LESSONS : LESSONS.filter((l) => l.module === activeModule);

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Academy</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">Learn local SEO without the fluff</h1>
        <p className="mt-2 text-base text-foreground/80">
          Short, plain English lessons written for owners. Each takes under 15 minutes and ends with steps you can do today.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="Lessons" value={`${LESSONS.length}`} hint="Hand picked" />
        <Stat label="Time" value={`${totalMinutes} min`} hint="Total learning" />
        <Stat label="Completed" value={`${completed} / ${LESSONS.length}`} hint="Keep going" />
      </div>

      <div className="flex flex-wrap gap-2">
        {(["All", ...MODULES] as const).map((m) => (
          <button
            key={m}
            onClick={() => setActiveModule(m)}
            className={`rounded-full border px-4 py-1.5 text-sm font-semibold transition ${
              activeModule === m ? "border-primary bg-primary text-primary-foreground" : "bg-background hover:border-primary/50"
            }`}
          >
            {m}
          </button>
        ))}
      </div>

      <div className="grid gap-4">
        {filtered.map((l) => (
          <LessonCard key={l.id} lesson={l} done={!!done[l.id]} onToggle={() => setDone({ ...done, [l.id]: !done[l.id] })} />
        ))}
      </div>
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-3xl border bg-card p-5">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 font-display text-3xl font-extrabold">{value}</div>
      <div className="text-xs text-muted-foreground">{hint}</div>
    </div>
  );
}

function LessonCard({ lesson, done, onToggle }: { lesson: Lesson; done: boolean; onToggle: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-3xl border bg-card p-5">
      <div className="flex items-start gap-3">
        <button
          onClick={onToggle}
          className={`mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full transition ${
            done ? "bg-primary text-primary-foreground" : "border-2 border-muted hover:border-primary"
          }`}
        >
          {done && <Check className="h-4 w-4" />}
        </button>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="secondary">{lesson.module}</Badge>
            <Badge
              variant="secondary"
              className={
                lesson.level === "beginner"
                  ? "bg-success/15 text-success-foreground"
                  : lesson.level === "intermediate"
                  ? "bg-accent/20 text-accent-foreground"
                  : "bg-destructive/10 text-destructive"
              }
            >
              {lesson.level}
            </Badge>
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" /> {lesson.minutes} min
            </span>
          </div>
          <h3 className={`mt-2 font-display text-lg font-bold ${done ? "line-through opacity-60" : ""}`}>
            {lesson.title}
          </h3>
          <p className="mt-1 text-sm text-foreground/75">{lesson.summary}</p>
          <Button variant="ghost" size="sm" className="mt-3 -ml-2 text-primary" onClick={() => setOpen(!open)}>
            <BookOpen className="mr-2 h-4 w-4" /> {open ? "Hide steps" : "Read the steps"}
            <ArrowRight className={`ml-2 h-3 w-3 transition ${open ? "rotate-90" : ""}`} />
          </Button>
          {open && (
            <ol className="mt-3 list-decimal space-y-2 rounded-2xl bg-secondary/50 p-4 pl-9 text-sm leading-relaxed">
              {lesson.steps.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ol>
          )}
        </div>
        <div className="hidden h-12 w-12 shrink-0 place-items-center rounded-2xl bg-primary/10 text-primary sm:grid">
          <GraduationCap className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
}
