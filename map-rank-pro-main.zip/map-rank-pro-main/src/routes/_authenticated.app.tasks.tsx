import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Check, Sparkles, Clock, Zap } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { generateWeeklyTasks } from "@/lib/ai.functions";
import { computeScore } from "@/lib/scoring";
import { Button } from "@/components/ui/button";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/app/tasks")({
  head: () => ({ meta: [{ title: "Weekly Tasks, Local Growth OS" }] }),
  component: TasksPage,
});

function TasksPage() {
  const { user, session } = useAuth();
  const { data: business } = useMyBusiness(user?.id);
  const qc = useQueryClient();
  const [generating, setGenerating] = useState(false);
  const generate = useServerFn(generateWeeklyTasks);

  const { data: tasks, isLoading } = useQuery({
    queryKey: ["tasks", business?.id],
    enabled: !!business?.id,
    queryFn: async () => {
      const { data } = await supabase
        .from("tasks").select("*").eq("business_id", business!.id)
        .order("status").order("priority").order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const onGenerate = async () => {
    if (!business || !session?.access_token) return;
    setGenerating(true);
    try {
      const { factors } = computeScore({
        review_count: business.review_count,
        avg_rating: Number(business.avg_rating),
        photo_count: business.photo_count,
        posting_freq: business.posting_freq,
        description: business.description,
        website: business.website,
        gbp_url: business.gbp_url,
        services: (business.services as unknown[]) ?? [],
        city: business.city,
      });
      const weakest = [...factors].sort((a, b) => a.earned / a.weight - b.earned / b.weight).slice(0, 4).map((f) => f.label);
      await generate({ data: { accessToken: session.access_token, businessId: business.id, weakestFactors: weakest } });
      qc.invalidateQueries({ queryKey: ["tasks", business.id] });
      toast.success("This week's plan is ready!");
    } catch (e: any) {
      toast.error(e.message ?? "Failed to generate tasks");
    } finally { setGenerating(false); }
  };

  const onComplete = async (taskId: string, xp: number) => {
    if (!business) return;
    const { error } = await supabase.from("tasks").update({ status: "done", completed_at: new Date().toISOString() }).eq("id", taskId);
    if (error) return toast.error(error.message);
    await supabase.from("xp_events").insert({ business_id: business.id, source: "task_complete", amount: xp });
    await supabase.from("businesses").update({ xp: business.xp + xp, last_active_date: new Date().toISOString().slice(0, 10) }).eq("id", business.id);
    qc.invalidateQueries({ queryKey: ["tasks", business.id] });
    qc.invalidateQueries({ queryKey: ["business", user?.id] });
    toast.success(`+${xp} XP! 🔥`);
  };

  const open = (tasks ?? []).filter((t) => t.status === "open");
  const done = (tasks ?? []).filter((t) => t.status === "done");

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Weekly tasks</div>
          <h1 className="mt-1 font-display text-3xl font-extrabold">Your growth plan</h1>
        </div>
        <Button onClick={onGenerate} disabled={generating} className="rounded-full">
          <Sparkles className="mr-2 h-4 w-4" />
          {generating ? "Generating…" : "Generate this week's plan"}
        </Button>
      </div>

      {isLoading ? <div className="text-muted-foreground">Loading…</div> : (
        <>
          {open.length === 0 && done.length === 0 && (
            <div className="rounded-3xl border-2 border-dashed bg-card p-12 text-center">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-primary/15 text-primary">
                <Sparkles className="h-7 w-7" />
              </div>
              <h3 className="mt-4 font-display text-xl font-bold">No tasks yet</h3>
              <p className="mt-1 text-sm text-foreground/70">Generate your first AI-powered weekly plan.</p>
            </div>
          )}

          {open.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Open ({open.length})</h2>
              {open.map((t) => <TaskCard key={t.id} task={t} onComplete={onComplete} />)}
            </div>
          )}
          {done.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Completed ({done.length})</h2>
              {done.map((t) => <TaskCard key={t.id} task={t} onComplete={onComplete} done />)}
            </div>
          )}
        </>
      )}
    </div>
  );
}

function TaskCard({ task, onComplete, done }: { task: any; onComplete: (id: string, xp: number) => void; done?: boolean }) {
  const priColor = task.priority === "p1" ? "bg-destructive/15 text-destructive" : task.priority === "p2" ? "bg-accent/20 text-accent-foreground" : "bg-muted text-muted-foreground";
  return (
    <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className={`rounded-2xl border bg-card p-4 ${done ? "opacity-60" : ""}`}>
      <div className="flex items-start gap-3">
        <button
          onClick={() => !done && onComplete(task.id, task.xp_awarded)}
          disabled={done}
          className={`mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full transition ${done ? "bg-primary text-primary-foreground" : "border-2 border-muted hover:border-primary"}`}
        >
          {done && <Check className="h-4 w-4" />}
        </button>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <Badge className={priColor + " border-0"}>{task.priority.toUpperCase()}</Badge>
            <span className="text-xs font-medium text-muted-foreground">{task.category}</span>
          </div>
          <h3 className={`mt-1 font-semibold ${done ? "line-through" : ""}`}>{task.title}</h3>
          <p className="mt-1 text-sm text-foreground/70">{task.why}</p>
          <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><Zap className="h-3 w-3 text-primary" /> +{task.impact_points} pts</span>
            <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {task.est_minutes} min</span>
            <span>+{task.xp_awarded} XP</span>
            {!done && (
              <Sheet>
                <SheetTrigger asChild>
                  <button className="ml-auto font-semibold text-primary hover:underline">How to do this →</button>
                </SheetTrigger>
                <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
                  <SheetHeader><SheetTitle>{task.title}</SheetTitle></SheetHeader>
                  <div className="prose prose-sm mt-6 max-w-none whitespace-pre-wrap text-sm">{task.tutorial_md}</div>
                  <Button className="mt-6 w-full rounded-full" onClick={() => onComplete(task.id, task.xp_awarded)}>
                    <Check className="mr-2 h-4 w-4" /> Mark done · +{task.xp_awarded} XP
                  </Button>
                </SheetContent>
              </Sheet>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
