import "@tanstack/react-start";
import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createLovableAiGatewayProvider, DEFAULT_MODEL } from "@/lib/ai-gateway";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const auth = request.headers.get("authorization");
        const token = auth?.replace("Bearer ", "");
        if (!token) return new Response("Unauthorized", { status: 401 });

        const { data: userData, error: userErr } = await supabaseAdmin.auth.getUser(token);
        if (userErr || !userData.user) return new Response("Unauthorized", { status: 401 });

        const body = (await request.json()) as { messages: UIMessage[]; businessId: string };
        if (!body.businessId || !Array.isArray(body.messages)) {
          return new Response("Invalid", { status: 400 });
        }

        const { data: biz } = await supabaseAdmin
          .from("businesses")
          .select("*")
          .eq("id", body.businessId)
          .eq("owner_id", userData.user.id)
          .maybeSingle();
        if (!biz) return new Response("Forbidden", { status: 403 });

        // Open tasks for context
        const { data: tasks } = await supabaseAdmin
          .from("tasks")
          .select("title, priority, impact_points, status")
          .eq("business_id", body.businessId)
          .eq("status", "open")
          .order("priority")
          .limit(10);

        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing AI key", { status: 500 });
        const model = createLovableAiGatewayProvider(key)(DEFAULT_MODEL);

        const system = `You are the AI Growth Coach for Local Growth OS — a friendly, action-oriented local SEO mentor for non-technical business owners.

CURRENT BUSINESS:
- ${biz.name} (${biz.category}) — ${biz.city}, ${biz.country}
- Growth Score: ${biz.current_score}/100 | XP: ${biz.xp} | Streak: ${biz.streak_days} days
- ${biz.review_count} reviews @ ${biz.avg_rating}★ | ${biz.photo_count} photos | posts ${biz.posting_freq}

OPEN TASKS THIS WEEK:
${(tasks ?? []).map((t) => `- [${t.priority.toUpperCase()}] ${t.title} (+${t.impact_points} pts)`).join("\n") || "- (none yet — recommend they generate this week's plan)"}

GOALS: ${JSON.stringify(biz.goals)}

RULES:
- Be encouraging and specific. Reference the business name and tasks.
- When recommending action, point to a specific open task or what to do next.
- Keep replies under 150 words. Use short paragraphs and emoji sparingly (max 2).
- Never recommend technical SEO jargon without a plain-English explanation.`;

        const result = streamText({
          model,
          system,
          messages: await convertToModelMessages(body.messages),
        });

        // Persist user message + assistant reply on finish
        const lastUser = body.messages[body.messages.length - 1];
        if (lastUser?.role === "user") {
          const userText = lastUser.parts
            .map((p) => (p.type === "text" ? p.text : ""))
            .join("");
          await supabaseAdmin.from("chat_messages").insert({
            business_id: body.businessId,
            role: "user",
            content: userText,
            parts: lastUser.parts as unknown as never,
          });
        }

        return result.toUIMessageStreamResponse({
          originalMessages: body.messages,
          onFinish: async ({ responseMessage }) => {
            const text = responseMessage.parts
              .map((p) => (p.type === "text" ? p.text : ""))
              .join("");
            await supabaseAdmin.from("chat_messages").insert({
              business_id: body.businessId,
              role: "assistant",
              content: text,
              parts: responseMessage.parts as unknown as never,
            });
          },
        });
      },
    },
  },
});
