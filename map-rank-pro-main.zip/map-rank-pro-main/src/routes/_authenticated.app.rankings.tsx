import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, TrendingUp, Search, Plus, X } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { estimateRankings } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/app/rankings")({
  head: () => ({ meta: [{ title: "Rankings · Local Growth OS" }] }),
  component: RankingsPage,
});

type Result = Awaited<ReturnType<typeof estimateRankings>>;

function RankingsPage() {
  const { user, session } = useAuth();
  const { data: b } = useMyBusiness(user?.id);
  const run = useServerFn(estimateRankings);
  const [extras, setExtras] = useState<string[]>([""]);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  const fire = async () => {
    if (!b || !session?.access_token) return;
    setBusy(true);
    try {
      const out = await run({
        data: {
          accessToken: session.access_token,
          businessId: b.id,
          extraKeywords: extras.map((x) => x.trim()).filter(Boolean),
        },
      });
      setResult(out);
      toast.success("Rankings estimated");
    } catch (e: any) {
      toast.error(e.message ?? "Failed to estimate");
    } finally {
      setBusy(false);
    }
  };

  if (!b) return null;

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Rankings</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">Where you sit on local search</h1>
        <p className="mt-2 text-base text-foreground/80">
          Get an AI estimated picture of how {b.name} likely ranks for the keywords your customers search every day in {b.city}.
        </p>
        <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-info/15 px-3 py-1.5 text-xs font-medium text-info-foreground">
          Heads up: estimates use your profile signals. Connect Google later for live rank tracking.
        </div>
      </div>

      <div className="rounded-3xl border bg-card p-6">
        <h3 className="font-display text-lg font-bold">Track your own keywords (optional)</h3>
        <p className="mt-1 text-sm text-foreground/70">Add up to 5 keywords your customers actually search.</p>
        <div className="mt-4 space-y-2">
          {extras.map((kw, i) => (
            <div key={i} className="flex gap-2">
              <Input
                value={kw}
                placeholder={`Keyword ${i + 1}, for example "best ${b.category.toLowerCase()} in ${b.city.toLowerCase()}"`}
                onChange={(e) => setExtras(extras.map((x, j) => (i === j ? e.target.value : x)))}
              />
              {extras.length > 1 && (
                <Button variant="ghost" size="icon" onClick={() => setExtras(extras.filter((_, j) => j !== i))}>
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
          {extras.length < 5 && (
            <Button variant="outline" size="sm" className="rounded-full" onClick={() => setExtras([...extras, ""])}>
              <Plus className="mr-2 h-4 w-4" /> Add keyword
            </Button>
          )}
        </div>
        <Button onClick={fire} disabled={busy} className="mt-5 rounded-full">
          <Sparkles className="mr-2 h-4 w-4" />
          {busy ? "Crunching numbers…" : "Estimate my rankings"}
        </Button>
      </div>

      {result && (
        <>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-3xl border bg-gradient-to-br from-primary/10 to-primary/5 p-6">
              <div className="text-xs font-bold uppercase tracking-wider text-primary">Overall visibility</div>
              <div className="mt-2 font-display text-5xl font-extrabold">{result.overall_visibility}</div>
              <div className="text-sm text-foreground/70">out of 100</div>
            </div>
            <div className="rounded-3xl border bg-gradient-to-br from-accent/15 to-accent/5 p-6">
              <div className="text-xs font-bold uppercase tracking-wider text-accent-foreground">Top priority keyword</div>
              <div className="mt-2 font-display text-2xl font-extrabold leading-tight">{result.top_priority_keyword}</div>
              <p className="mt-2 text-sm text-foreground/80">Win this and most of the others follow.</p>
            </div>
          </div>

          <div className="overflow-hidden rounded-3xl border bg-card">
            <div className="grid grid-cols-[1fr_70px_90px_90px] gap-3 border-b bg-secondary/40 px-5 py-3 text-xs font-bold uppercase tracking-wider text-muted-foreground sm:grid-cols-[1fr_70px_110px_110px_110px]">
              <div>Keyword</div>
              <div className="text-center">Rank</div>
              <div className="hidden text-center sm:block">Volume</div>
              <div className="text-center">Difficulty</div>
              <div className="text-center">Intent</div>
            </div>
            {result.keywords.map((k, i) => (
              <div
                key={i}
                className="grid grid-cols-[1fr_70px_90px_90px] items-start gap-3 border-b px-5 py-4 last:border-0 sm:grid-cols-[1fr_70px_110px_110px_110px]"
              >
                <div>
                  <div className="flex items-center gap-2 font-semibold text-foreground">
                    <Search className="h-3.5 w-3.5 text-muted-foreground" /> {k.keyword}
                  </div>
                  <p className="mt-1 text-sm text-foreground/70">{k.why_this_rank}</p>
                  <p className="mt-1 text-sm">
                    <span className="font-semibold text-primary">Action: </span>
                    {k.action_to_improve}
                  </p>
                </div>
                <div className="text-center">
                  <span
                    className={`inline-grid h-10 w-10 place-items-center rounded-xl font-display text-base font-extrabold ${
                      k.estimated_rank <= 3
                        ? "bg-success/20 text-success-foreground"
                        : k.estimated_rank <= 10
                        ? "bg-accent/25 text-accent-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {k.estimated_rank <= 50 ? `#${k.estimated_rank}` : "50+"}
                  </span>
                </div>
                <div className="hidden text-center text-sm sm:block">
                  <Badge variant="secondary" className="capitalize">
                    {k.search_volume_band}
                  </Badge>
                </div>
                <div className="text-center text-sm">
                  <Badge
                    variant="secondary"
                    className={
                      k.difficulty === "easy"
                        ? "bg-success/15 text-success-foreground"
                        : k.difficulty === "moderate"
                        ? "bg-accent/15 text-accent-foreground"
                        : "bg-destructive/10 text-destructive"
                    }
                  >
                    {k.difficulty}
                  </Badge>
                </div>
                <div className="text-center text-xs uppercase tracking-wide text-muted-foreground">
                  <span className="hidden sm:inline">{k.intent}</span>
                  <span className="sm:hidden">
                    <TrendingUp className="mx-auto h-3 w-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
