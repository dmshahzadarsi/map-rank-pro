import { createFileRoute, Outlet } from "@tanstack/react-router";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { AppShell } from "@/components/app/AppShell";
import { Sparkles } from "lucide-react";

export const Route = createFileRoute("/_authenticated/app")({
  component: AppLayout,
});

function AppLayout() {
  const { user, loading: authLoading } = useAuth();
  const { data: business, isLoading } = useMyBusiness(user?.id);

  if (authLoading || (user && isLoading)) {
    return (
      <div className="grid min-h-screen place-items-center text-muted-foreground">
        <Sparkles className="h-5 w-5 animate-pulse text-primary" />
      </div>
    );
  }

  if (!business) {
    if (typeof window !== "undefined") window.location.href = "/onboarding";
    return null;
  }

  return (
    <AppShell business={business}>
      <Outlet />
    </AppShell>
  );
}
