import { createFileRoute } from "@tanstack/react-router";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { ScoreRing } from "@/components/app/ScoreRing";
import { FactorBar } from "@/components/app/FactorBar";
import { computeScore } from "@/lib/scoring";

export const Route = createFileRoute("/_authenticated/app/score")({
  head: () => ({ meta: [{ title: "Growth Score, Local Growth OS" }] }),
  component: ScorePage,
});

function ScorePage() {
  const { user } = useAuth();
  const { data: b } = useMyBusiness(user?.id);
  if (!b) return null;
  const { score, factors } = computeScore({
    review_count: b.review_count,
    avg_rating: Number(b.avg_rating),
    photo_count: b.photo_count,
    posting_freq: b.posting_freq,
    description: b.description,
    website: b.website,
    gbp_url: b.gbp_url,
    services: (b.services as unknown[]) ?? [],
    city: b.city,
  });

  const sorted = [...factors].sort((a, c) => a.earned / a.weight - c.earned / c.weight);

  return (
    <div className="mx-auto max-w-5xl space-y-8">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Growth Score</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">How visible is your business?</h1>
      </div>

      <div className="grid gap-6 lg:grid-cols-[auto_1fr]">
        <div className="rounded-3xl border bg-card p-6 grid place-items-center">
          <ScoreRing score={score} size={240} />
        </div>
        <div className="rounded-3xl border bg-gradient-to-br from-primary/10 to-accent/10 p-6">
          <div className="text-xs font-bold uppercase tracking-wider text-primary">Biggest wins available</div>
          <ul className="mt-3 space-y-2">
            {sorted.slice(0, 3).map((f) => (
              <li key={f.key} className="flex items-baseline justify-between gap-3 text-sm">
                <span className="font-medium">{f.label}</span>
                <span className="text-xs text-muted-foreground">+{f.weight - f.earned} pts available</span>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-sm text-foreground/70">
            Tackle these in your <a href="/app/tasks" className="font-semibold text-primary underline">weekly plan</a>.
          </p>
        </div>
      </div>

      <div>
        <h2 className="mb-3 font-display text-xl font-bold">All factors</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {factors.map((f) => <FactorBar key={f.key} factor={f} />)}
        </div>
      </div>
    </div>
  );
}
