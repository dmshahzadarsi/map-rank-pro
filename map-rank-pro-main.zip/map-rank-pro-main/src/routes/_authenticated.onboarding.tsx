import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, ArrowLeft, Sparkles, Check } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { supabase } from "@/integrations/supabase/client";
import { computeScore } from "@/lib/scoring";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/onboarding")({
  head: () => ({ meta: [{ title: "Set up your business, Local Growth OS" }] }),
  component: Onboarding,
});

const CATEGORIES = [
  "Dentist", "Salon", "Hair stylist", "Plumber", "Electrician",
  "Appliance repair", "Restaurant", "Café", "Interior designer",
  "Med spa", "HVAC", "Clinic", "Auto repair", "Lawyer", "Accountant",
  "Cleaning service", "Roofer", "Landscaper", "Real estate agent", "Other",
];

const POST_FREQ = [
  { v: "never", l: "Never" },
  { v: "monthly", l: "Monthly" },
  { v: "weekly", l: "Weekly" },
  { v: "daily", l: "Daily" },
];

const GOAL_OPTIONS = [
  "More phone calls", "More 5-star reviews", "Beat a specific competitor",
  "Rank higher on Google Maps", "More website visits", "More foot traffic",
  "Better profile completeness", "Stronger brand authority",
];

const TOTAL = 5;

function Onboarding() {
  const { user, loading: authLoading } = useAuth();
  const { data: existing, isLoading: bizLoading } = useMyBusiness(user?.id);
  const nav = useNavigate();

  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);

  const [form, setForm] = useState({
    name: "",
    category: "",
    city: "",
    country: "",
    service_area: "",
    website: "",
    gbp_url: "",
    description: "",
    review_count: 0,
    avg_rating: 4.5,
    photo_count: 0,
    posting_freq: "never",
    years_in_business: 1,
    goals: [] as string[],
    services: [] as string[],
  });

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  if (authLoading || bizLoading) {
    return <div className="grid min-h-screen place-items-center text-muted-foreground">Loading…</div>;
  }

  if (existing) {
    if (typeof window !== "undefined") window.location.href = "/app";
    return null;
  }

  const next = () => setStep((s) => Math.min(TOTAL, s + 1));
  const back = () => setStep((s) => Math.max(1, s - 1));

  const valid = () => {
    if (step === 1) return form.name.trim().length > 1 && !!form.category;
    if (step === 2) return form.city.trim() && form.country.trim();
    if (step === 5) return form.goals.length > 0;
    return true;
  };

  const submit = async () => {
    if (!user) return;
    setSubmitting(true);
    const { score } = computeScore({
      review_count: form.review_count,
      avg_rating: form.avg_rating,
      photo_count: form.photo_count,
      posting_freq: form.posting_freq,
      description: form.description,
      website: form.website || null,
      gbp_url: form.gbp_url || null,
      services: form.services,
      city: form.city,
    });

    const { error } = await supabase.from("businesses").insert({
      owner_id: user.id,
      name: form.name,
      category: form.category,
      city: form.city,
      country: form.country,
      service_area: form.service_area || null,
      website: form.website || null,
      gbp_url: form.gbp_url || null,
      description: form.description || null,
      review_count: form.review_count,
      avg_rating: form.avg_rating,
      photo_count: form.photo_count,
      posting_freq: form.posting_freq,
      years_in_business: form.years_in_business,
      goals: form.goals,
      services: form.services,
      current_score: score,
    });
    setSubmitting(false);
    if (error) return toast.error(error.message);
    toast.success("You're all set! Let's grow.");
    nav({ to: "/app" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/5">
      <div className="mx-auto max-w-2xl px-4 py-10 sm:py-16">
        <div className="mb-8 flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground">
            <Sparkles className="h-5 w-5" />
          </div>
          <span className="font-display text-lg font-bold">Local Growth OS</span>
        </div>

        <div className="mb-6">
          <div className="mb-2 flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            <span>Step {step} of {TOTAL}</span>
            <span>{Math.round((step / TOTAL) * 100)}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
            <motion.div
              className="h-full bg-gradient-to-r from-primary to-accent"
              animate={{ width: `${(step / TOTAL) * 100}%` }}
              transition={{ duration: 0.4 }}
            />
          </div>
        </div>

        <div className="rounded-3xl border bg-card p-6 shadow-xl shadow-primary/5 sm:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -12 }}
              transition={{ duration: 0.25 }}
            >
              {step === 1 && (
                <Step title="What's your business?" subtitle="The basics, we'll personalize everything from here.">
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <Label>Business name</Label>
                      <Input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Bright Smile Dental" />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Category</Label>
                      <Select value={form.category} onValueChange={(v) => set("category", v)}>
                        <SelectTrigger><SelectValue placeholder="Pick your business type" /></SelectTrigger>
                        <SelectContent>
                          {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </Step>
              )}

              {step === 2 && (
                <Step title="Where are you?" subtitle="We use this for local-keyword recommendations.">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label>City</Label>
                        <Input value={form.city} onChange={(e) => set("city", e.target.value)} placeholder="Austin" />
                      </div>
                      <div className="space-y-1.5">
                        <Label>Country</Label>
                        <Input value={form.country} onChange={(e) => set("country", e.target.value)} placeholder="USA" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label>Service area (optional)</Label>
                      <Input value={form.service_area} onChange={(e) => set("service_area", e.target.value)} placeholder="Greater Austin" />
                    </div>
                  </div>
                </Step>
              )}

              {step === 3 && (
                <Step title="Your web presence" subtitle="Skip anything you don't have yet.">
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <Label>Website URL</Label>
                      <Input value={form.website} onChange={(e) => set("website", e.target.value)} placeholder="https://" />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Google Business Profile URL</Label>
                      <Input value={form.gbp_url} onChange={(e) => set("gbp_url", e.target.value)} placeholder="https://maps.google.com/..." />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Short business description</Label>
                      <Textarea
                        value={form.description}
                        onChange={(e) => set("description", e.target.value)}
                        rows={4}
                        placeholder="What you do, who for, what makes you different."
                      />
                    </div>
                  </div>
                </Step>
              )}

              {step === 4 && (
                <Step title="Honest snapshot" subtitle="Your starting point. No judgment, this is how we measure progress.">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-3">
                      <NumField label="Reviews" value={form.review_count} onChange={(v) => set("review_count", v)} />
                      <NumField label="Avg rating" value={form.avg_rating} onChange={(v) => set("avg_rating", v)} step={0.1} max={5} />
                      <NumField label="Photos" value={form.photo_count} onChange={(v) => set("photo_count", v)} />
                      <NumField label="Years in business" value={form.years_in_business} onChange={(v) => set("years_in_business", v)} />
                    </div>
                    <div className="space-y-1.5">
                      <Label>How often do you post on Google?</Label>
                      <Select value={form.posting_freq} onValueChange={(v) => set("posting_freq", v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {POST_FREQ.map((p) => <SelectItem key={p.v} value={p.v}>{p.l}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </Step>
              )}

              {step === 5 && (
                <Step title="Pick your goals" subtitle="Choose 1, 3, your weekly plan will focus on these.">
                  <div className="grid grid-cols-2 gap-2">
                    {GOAL_OPTIONS.map((g) => {
                      const active = form.goals.includes(g);
                      return (
                        <button
                          key={g}
                          type="button"
                          onClick={() => {
                            if (active) set("goals", form.goals.filter((x) => x !== g));
                            else if (form.goals.length < 3) set("goals", [...form.goals, g]);
                          }}
                          className={`flex items-center gap-2 rounded-xl border-2 p-3 text-left text-sm font-medium transition ${
                            active
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border hover:border-primary/40"
                          }`}
                        >
                          <div className={`grid h-5 w-5 place-items-center rounded-full ${active ? "bg-primary text-primary-foreground" : "border-2 border-muted"}`}>
                            {active && <Check className="h-3 w-3" />}
                          </div>
                          {g}
                        </button>
                      );
                    })}
                  </div>
                </Step>
              )}
            </motion.div>
          </AnimatePresence>

          <div className="mt-8 flex items-center justify-between">
            <Button variant="ghost" onClick={back} disabled={step === 1} className="rounded-full">
              <ArrowLeft className="mr-1 h-4 w-4" /> Back
            </Button>
            {step < TOTAL ? (
              <Button onClick={next} disabled={!valid()} className="h-11 rounded-full px-6">
                Continue <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            ) : (
              <Button onClick={submit} disabled={!valid() || submitting} className="h-11 rounded-full px-6">
                {submitting ? "Setting up…" : "See my Growth Score"}
                <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Step({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="font-display text-2xl font-extrabold">{title}</h2>
      <p className="mt-1 text-sm text-foreground/70">{subtitle}</p>
      <div className="mt-6">{children}</div>
    </div>
  );
}

function NumField({ label, value, onChange, step = 1, max }: { label: string; value: number; onChange: (n: number) => void; step?: number; max?: number }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Input
        type="number"
        min={0}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </div>
  );
}
