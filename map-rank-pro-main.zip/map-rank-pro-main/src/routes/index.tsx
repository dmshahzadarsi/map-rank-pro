import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  Sparkles,
  ArrowRight,
  Check,
  X,
  Star,
  Flame,
  Zap,
  ListChecks,
  Building2,
  MessageCircle,
  Gauge,
  TrendingUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Local Growth OS, Your AI growth coach for local SEO" },
      {
        name: "description",
        content:
          "Stop guessing how to rank on Google Maps. Get a weekly action plan, AI coaching, and a Growth Score that goes up.",
      },
      { property: "og:title", content: "Local Growth OS, AI Growth Coach for Local Businesses" },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Hero />
      <Logos />
      <HowItWorks />
      <Features />
      <Comparison />
      <Testimonials />
      <Faq />
      <FinalCta />
      <Footer />
    </div>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground shadow-sm">
            <Sparkles className="h-5 w-5" />
          </div>
          <span className="font-display text-lg font-bold">Local Growth OS</span>
        </Link>
        <nav className="hidden items-center gap-8 md:flex">
          <a href="#how" className="text-sm font-medium text-foreground/70 hover:text-foreground">How it works</a>
          <a href="#features" className="text-sm font-medium text-foreground/70 hover:text-foreground">Features</a>
          <a href="#faq" className="text-sm font-medium text-foreground/70 hover:text-foreground">FAQ</a>
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/login" className="hidden text-sm font-medium text-foreground/80 hover:text-foreground sm:block">
            Sign in
          </Link>
          <Button asChild size="sm" className="rounded-full px-5">
            <Link to="/signup">Start free</Link>
          </Button>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-primary/10 via-background to-background" />
      <div className="absolute -left-32 top-32 -z-10 h-96 w-96 rounded-full bg-primary/20 blur-3xl" />
      <div className="absolute -right-32 top-12 -z-10 h-96 w-96 rounded-full bg-accent/20 blur-3xl" />

      <div className="mx-auto max-w-7xl px-4 pb-24 pt-16 sm:px-6 lg:px-8 lg:pb-32 lg:pt-24">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 rounded-full border bg-background/60 px-3 py-1.5 text-xs font-semibold text-foreground/80 backdrop-blur">
              <span className="grid h-4 w-4 place-items-center rounded-full bg-primary text-[10px] text-primary-foreground">★</span>
              Built for non-technical owners
            </div>
            <h1 className="mt-4 font-display text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
              Rank higher on Google Maps,{" "}
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                one task at a time.
              </span>
            </h1>
            <p className="mt-5 max-w-lg text-lg text-foreground/70">
              Local Growth OS is your AI coach for local SEO. Get a weekly action plan,
              a Growth Score that goes up, and the exact next step to beat your competition.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Button asChild size="lg" className="h-12 rounded-full px-7 text-base font-semibold shadow-lg shadow-primary/30">
                <Link to="/signup">
                  Start free <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="h-12 rounded-full px-7 text-base font-semibold">
                <a href="#how">See how it works</a>
              </Button>
            </div>
            <div className="mt-6 flex flex-wrap gap-x-5 gap-y-2 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><Check className="h-3.5 w-3.5 text-primary" /> No credit card</span>
              <span className="flex items-center gap-1"><Check className="h-3.5 w-3.5 text-primary" /> Setup in 3 minutes</span>
              <span className="flex items-center gap-1"><Check className="h-3.5 w-3.5 text-primary" /> AI coach included</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="relative"
          >
            <DashboardMock />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function DashboardMock() {
  return (
    <div className="relative mx-auto max-w-md rounded-3xl border bg-card p-5 shadow-2xl shadow-primary/10">
      <div className="flex items-center justify-between">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">This week</div>
        <div className="flex items-center gap-2 rounded-full bg-accent/15 px-2.5 py-1 text-xs font-bold text-accent-foreground">
          <Flame className="h-3 w-3 text-accent" /> 12 day streak
        </div>
      </div>

      <div className="mt-4 grid grid-cols-[auto_1fr] items-center gap-4">
        <div className="relative h-28 w-28">
          <svg viewBox="0 0 100 100" className="-rotate-90">
            <circle cx="50" cy="50" r="42" stroke="var(--color-secondary)" strokeWidth="10" fill="none" />
            <motion.circle
              cx="50" cy="50" r="42" stroke="url(#g1)" strokeWidth="10" fill="none" strokeLinecap="round"
              strokeDasharray="264" initial={{ strokeDashoffset: 264 }} animate={{ strokeDashoffset: 264 - 0.74 * 264 }}
              transition={{ duration: 1.4, ease: "easeOut" }}
            />
            <defs>
              <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="var(--color-primary)" />
                <stop offset="100%" stopColor="var(--color-accent)" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="font-display text-2xl font-extrabold">74</div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Score</div>
          </div>
        </div>
        <div>
          <div className="text-xs text-muted-foreground">Top win this week</div>
          <div className="mt-1 font-semibold">Reply to 4 unanswered reviews</div>
          <div className="mt-1 text-xs text-primary">+8 pts · 15 min</div>
        </div>
      </div>

      <div className="mt-5 space-y-2">
        {[
          { t: "Upload 5 interior photos", d: "+6 pts", done: true },
          { t: "Publish a Google post", d: "+4 pts", done: false },
          { t: "Add 3 service descriptions", d: "+5 pts", done: false },
        ].map((x) => (
          <div key={x.t} className="flex items-center gap-3 rounded-xl border bg-background px-3 py-2.5">
            <div className={`grid h-6 w-6 place-items-center rounded-full ${x.done ? "bg-primary text-primary-foreground" : "border-2 border-muted"}`}>
              {x.done && <Check className="h-3.5 w-3.5" />}
            </div>
            <div className={`flex-1 text-sm font-medium ${x.done ? "line-through text-muted-foreground" : ""}`}>{x.t}</div>
            <div className="text-xs font-bold text-primary">{x.d}</div>
          </div>
        ))}
      </div>

      <div className="mt-4 flex items-center gap-2 rounded-xl bg-primary/10 p-3 text-xs">
        <Sparkles className="h-4 w-4 text-primary" />
        <span><b>AI Coach:</b> Photos move you up the most this week.</span>
      </div>
    </div>
  );
}

function Logos() {
  const cats = ["Dentists", "Salons", "Plumbers", "Restaurants", "HVAC", "Med Spas", "Clinics"];
  return (
    <section className="border-y bg-secondary/30 py-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Built for local service businesses
        </p>
        <div className="mt-4 flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
          {cats.map((c) => (
            <span key={c} className="font-display text-base font-bold text-foreground/40">
              {c}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    { n: "1", title: "Tell us about your business", body: "3-minute setup. No technical skills.", icon: Building2 },
    { n: "2", title: "Get your Growth Score", body: "See exactly what's holding you back from ranking.", icon: Gauge },
    { n: "3", title: "Do this week's tasks", body: "5, 7 hand-picked actions with step-by-step tutorials.", icon: ListChecks },
  ];
  return (
    <section id="how" className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-center font-display text-3xl font-extrabold sm:text-4xl">How it works</h2>
        <p className="mx-auto mt-3 max-w-xl text-center text-foreground/70">
          A guided system, not another dashboard. Every week you get a tiny, focused plan.
        </p>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {steps.map((s) => (
            <div key={s.n} className="rounded-3xl border bg-card p-7 shadow-sm transition hover:-translate-y-1 hover:shadow-lg">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-primary text-primary-foreground">
                <s.icon className="h-6 w-6" />
              </div>
              <div className="mt-5 text-xs font-bold uppercase tracking-wider text-primary">Step {s.n}</div>
              <h3 className="mt-1 text-xl font-bold">{s.title}</h3>
              <p className="mt-2 text-sm text-foreground/70">{s.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Features() {
  const f = [
    { icon: Gauge, title: "Growth Score", body: "A single number that shows how you stack up, and what to fix first." },
    { icon: ListChecks, title: "Weekly action plan", body: "5, 7 AI-picked tasks with tutorials, XP, and impact estimates." },
    { icon: Building2, title: "GBP optimizer", body: "Generate posts, descriptions, and FAQs that actually use local keywords." },
    { icon: Star, title: "Review engine", body: "QR codes, WhatsApp links, and AI replies for every review you get." },
    { icon: MessageCircle, title: "AI Growth Coach", body: "Chat anytime. It knows your business, your score, and your tasks." },
    { icon: Flame, title: "Streaks & XP", body: "Stay consistent. The owners who win are the ones who show up every week." },
  ];
  return (
    <section id="features" className="bg-secondary/40 py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-center font-display text-3xl font-extrabold sm:text-4xl">
          Everything you need. Nothing you don't.
        </h2>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {f.map((x) => (
            <div key={x.title} className="rounded-3xl border bg-card p-6">
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-primary/15 text-primary">
                <x.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-lg font-bold">{x.title}</h3>
              <p className="mt-1 text-sm text-foreground/70">{x.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Comparison() {
  const rows = [
    ["Tells you what to do next", true, false],
    ["AI growth coach", true, false],
    ["Weekly action plan with XP", true, false],
    ["Beginner-friendly tutorials", true, false],
    ["Endless metrics with no advice", false, true],
    ["Requires SEO knowledge", false, true],
  ];
  return (
    <section className="py-24">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-center font-display text-3xl font-extrabold sm:text-4xl">
          Why owners pick us over generic SEO tools
        </h2>
        <div className="mt-10 overflow-hidden rounded-3xl border bg-card">
          <div className="grid grid-cols-[1fr_140px_140px] gap-4 border-b bg-secondary/40 px-5 py-4 text-sm font-semibold">
            <div></div>
            <div className="text-center text-primary">Local Growth OS</div>
            <div className="text-center text-muted-foreground">Generic SEO tools</div>
          </div>
          {rows.map(([label, a, b]) => (
            <div key={String(label)} className="grid grid-cols-[1fr_140px_140px] items-center gap-4 border-b px-5 py-3.5 text-sm last:border-0">
              <div className="font-medium">{label as string}</div>
              <div className="grid place-items-center">
                {a ? <Check className="h-5 w-5 text-primary" /> : <X className="h-5 w-5 text-muted-foreground/40" />}
              </div>
              <div className="grid place-items-center">
                {b ? <Check className="h-5 w-5 text-primary" /> : <X className="h-5 w-5 text-muted-foreground/40" />}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const t = [
    { name: "Priya, dentist", body: "I went from 12 reviews to 84 in two months. The weekly plan made it doable.", role: "Mumbai" },
    { name: "Marco, salon owner", body: "Finally an SEO tool that doesn't make me feel stupid. The coach is gold.", role: "Brooklyn" },
    { name: "Sara, plumber", body: "I got 3 new calls in the first week from improving my GBP description.", role: "Manchester" },
  ];
  return (
    <section className="bg-secondary/40 py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-center font-display text-3xl font-extrabold sm:text-4xl">Owners are shipping again</h2>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {t.map((x) => (
            <div key={x.name} className="rounded-3xl border bg-card p-6">
              <div className="flex gap-0.5 text-accent">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
              <p className="mt-3 text-sm text-foreground/80">"{x.body}"</p>
              <div className="mt-4 text-sm font-semibold">{x.name}</div>
              <div className="text-xs text-muted-foreground">{x.role}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Faq() {
  const items = [
    { q: "Do I need any SEO knowledge?", a: "No. Every task includes a step-by-step tutorial written for non-technical owners." },
    { q: "Will this actually move my Google Maps ranking?", a: "Yes, the tasks target the exact factors Google uses: reviews, photos, posts, profile completeness, and keyword coverage. Consistency is the trick." },
    { q: "How long does setup take?", a: "About 3 minutes. You answer 5 quick questions about your business and get your plan immediately." },
    { q: "Do you connect to my Google Business Profile?", a: "In v1 we don't auto-sync, you act on each task in your real GBP. Auto-sync is coming." },
    { q: "What types of businesses is this for?", a: "Any local service business: dentists, salons, plumbers, electricians, med spas, restaurants, HVAC, and more." },
  ];
  return (
    <section id="faq" className="py-24">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-center font-display text-3xl font-extrabold sm:text-4xl">Frequently asked</h2>
        <Accordion type="single" collapsible className="mt-8">
          {items.map((x, i) => (
            <AccordionItem key={i} value={`i${i}`}>
              <AccordionTrigger className="text-left text-base font-semibold">{x.q}</AccordionTrigger>
              <AccordionContent className="text-foreground/70">{x.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}

function FinalCta() {
  return (
    <section className="px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-primary to-primary/80 p-12 text-center text-primary-foreground shadow-2xl shadow-primary/30 sm:p-16">
        <div className="inline-flex items-center gap-2 rounded-full bg-primary-foreground/15 px-3 py-1 text-xs font-semibold backdrop-blur">
          <Zap className="h-3.5 w-3.5" /> Free during beta
        </div>
        <h2 className="mt-4 font-display text-3xl font-extrabold sm:text-5xl">
          Your competition isn't sleeping.
        </h2>
        <p className="mx-auto mt-3 max-w-xl text-base text-primary-foreground/80 sm:text-lg">
          Get your Growth Score in 3 minutes and see what's between you and rank #1.
        </p>
        <Button asChild size="lg" variant="secondary" className="mt-7 h-12 rounded-full px-7 text-base font-semibold">
          <Link to="/signup">Get my Growth Score <TrendingUp className="ml-1 h-4 w-4" /></Link>
        </Button>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t py-10">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 sm:flex-row sm:px-6 lg:px-8">
        <div className="flex items-center gap-2">
          <div className="grid h-7 w-7 place-items-center rounded-lg bg-primary text-primary-foreground">
            <Sparkles className="h-3.5 w-3.5" />
          </div>
          <span className="font-display text-sm font-bold">Local Growth OS</span>
        </div>
        <div className="text-xs text-muted-foreground">© {new Date().getFullYear()} Local Growth OS</div>
      </div>
    </footer>
  );
}
