import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, Copy, FileText, Mail, Megaphone, Layout } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { generateMarketingContent } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/app/ai-content")({
  head: () => ({ meta: [{ title: "AI Content · Local Growth OS" }] }),
  component: AiContentPage,
});

type Result = Awaited<ReturnType<typeof generateMarketingContent>>;

const KINDS = [
  { value: "blog", icon: FileText, label: "Local SEO blog post", hint: "800 words optimized for your city and service" },
  { value: "landing", icon: Layout, label: "Landing page copy", hint: "Hero, benefits, social proof, CTA" },
  { value: "email", icon: Mail, label: "Customer email", hint: "250 word win back email to past customers" },
  { value: "social", icon: Megaphone, label: "Social media week", hint: "5 posts with captions and hashtags" },
] as const;

function AiContentPage() {
  const { user, session } = useAuth();
  const { data: b } = useMyBusiness(user?.id);
  const run = useServerFn(generateMarketingContent);
  const [kind, setKind] = useState<(typeof KINDS)[number]["value"]>("blog");
  const [topic, setTopic] = useState("");
  const [tone, setTone] = useState<"friendly" | "professional" | "bold">("friendly");
  const [busy, setBusy] = useState(false);
  const [out, setOut] = useState<Result | null>(null);

  const fire = async () => {
    if (!b || !session?.access_token || !topic.trim()) return;
    setBusy(true);
    try {
      const res = await run({
        data: { accessToken: session.access_token, businessId: b.id, kind, topic, tone },
      });
      setOut(res);
    } catch (e: any) {
      toast.error(e.message ?? "Generation failed");
    } finally {
      setBusy(false);
    }
  };

  const copy = (s: string) => {
    navigator.clipboard.writeText(s);
    toast.success("Copied");
  };

  if (!b) return null;

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">AI Content</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">Marketing copy in seconds</h1>
        <p className="mt-2 text-base text-foreground/80">
          Pick a format, give a topic, and we draft real, local sounding copy you can ship today.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {KINDS.map((k) => {
          const active = kind === k.value;
          return (
            <button
              key={k.value}
              onClick={() => setKind(k.value)}
              className={`rounded-2xl border bg-card p-4 text-left transition hover:border-primary/50 ${
                active ? "border-primary ring-2 ring-primary/30" : ""
              }`}
            >
              <div className={`grid h-9 w-9 place-items-center rounded-xl ${active ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary"}`}>
                <k.icon className="h-4 w-4" />
              </div>
              <div className="mt-3 font-semibold">{k.label}</div>
              <div className="mt-1 text-xs text-foreground/70">{k.hint}</div>
            </button>
          );
        })}
      </div>

      <div className="rounded-3xl border bg-card p-6 space-y-4">
        <div className="space-y-1.5">
          <Label>Topic or angle</Label>
          <Input
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder={`Example: 5 reasons people in ${b.city} choose us for ${b.category.toLowerCase()}`}
          />
        </div>
        <div className="space-y-1.5">
          <Label>Tone</Label>
          <Select value={tone} onValueChange={(v) => setTone(v as any)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="friendly">Friendly and warm</SelectItem>
              <SelectItem value="professional">Polished and expert</SelectItem>
              <SelectItem value="bold">Bold and energetic</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button onClick={fire} disabled={busy || !topic.trim()} className="rounded-full">
          <Sparkles className="mr-2 h-4 w-4" />
          {busy ? "Writing your draft…" : "Write with AI"}
        </Button>
      </div>

      {out && (
        <div className="space-y-4">
          <div className="rounded-3xl border bg-gradient-to-br from-primary/10 to-accent/10 p-6">
            <div className="text-xs font-bold uppercase tracking-wider text-primary">SEO ready</div>
            <h2 className="mt-2 font-display text-2xl font-extrabold leading-tight">{out.title}</h2>
            <p className="mt-2 text-sm text-foreground/80">{out.meta_description}</p>
          </div>

          <Block title="Outline">
            <ol className="list-decimal space-y-1 pl-5 text-sm leading-relaxed">
              {out.outline.map((o, i) => (
                <li key={i}>{o}</li>
              ))}
            </ol>
          </Block>

          <Block title="Body" copyText={out.body_markdown} onCopy={copy}>
            <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">{out.body_markdown}</pre>
          </Block>

          <div className="grid gap-4 md:grid-cols-2">
            <Block title="Social caption" copyText={out.social_caption} onCopy={copy}>
              <p className="text-sm leading-relaxed">{out.social_caption}</p>
            </Block>
            <Block title="Email subject line" copyText={out.email_subject} onCopy={copy}>
              <p className="font-semibold leading-relaxed">{out.email_subject}</p>
            </Block>
          </div>
        </div>
      )}
    </div>
  );
}

function Block({
  title,
  children,
  copyText,
  onCopy,
}: {
  title: string;
  children: React.ReactNode;
  copyText?: string;
  onCopy?: (s: string) => void;
}) {
  return (
    <div className="rounded-3xl border bg-card p-5">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-semibold">{title}</h3>
        {copyText && (
          <Button variant="ghost" size="sm" onClick={() => onCopy?.(copyText)}>
            <Copy className="mr-2 h-3 w-3" /> Copy
          </Button>
        )}
      </div>
      {children}
    </div>
  );
}
