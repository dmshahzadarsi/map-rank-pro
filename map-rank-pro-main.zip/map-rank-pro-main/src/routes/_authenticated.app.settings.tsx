import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";

export const Route = createFileRoute("/_authenticated/app/settings")({
  head: () => ({ meta: [{ title: "Settings, Local Growth OS" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user } = useAuth();
  const { data: b } = useMyBusiness(user?.id);

  const signOut = async () => {
    await supabase.auth.signOut();
    toast.success("Signed out");
    window.location.href = "/";
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Settings</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">Your account</h1>
      </div>
      <div className="rounded-3xl border bg-card p-6">
        <h3 className="font-semibold">Profile</h3>
        <dl className="mt-4 space-y-3 text-sm">
          <Row label="Email" value={user?.email ?? ", "} />
          <Row label="Business" value={b?.name ?? ", "} />
          <Row label="Category" value={b?.category ?? ", "} />
          <Row label="Location" value={b ? `${b.city}, ${b.country}` : ", "} />
        </dl>
      </div>
      <div className="rounded-3xl border bg-card p-6">
        <h3 className="font-semibold">Session</h3>
        <Button onClick={signOut} variant="destructive" className="mt-4 rounded-full">
          <LogOut className="mr-2 h-4 w-4" /> Sign out
        </Button>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b py-2 last:border-0">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="font-medium">{value}</dd>
    </div>
  );
}
