import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, Copy, Check } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { generateGbpContent } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/app/gbp")({
  head: () => ({ meta: [{ title: "Google Business Profile, Local Growth OS" }] }),
  component: GbpPage,
});

const CHECKLIST = [
  "Primary category set", "Secondary categories added", "All services listed",
  "Business hours accurate", "Description (600+ chars)", "10+ photos uploaded",
  "Posted in the last 7 days", "8+ FAQs answered", "All attributes filled",
  "Booking link added",
];

function GbpPage() {
  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Google Business Profile</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">Optimize your GBP</h1>
      </div>

      <Tabs defaultValue="checklist">
        <TabsList className="rounded-full">
          <TabsTrigger value="checklist" className="rounded-full">Checklist</TabsTrigger>
          <TabsTrigger value="studio" className="rounded-full">AI Content Studio</TabsTrigger>
        </TabsList>
        <TabsContent value="checklist" className="mt-5">
          <div className="rounded-3xl border bg-card p-5">
            <h3 className="font-semibold">Profile completeness</h3>
            <p className="mt-1 text-sm text-foreground/70">Tick off each item in your real Google Business Profile.</p>
            <ul className="mt-4 space-y-2">
              {CHECKLIST.map((item) => <ChecklistRow key={item} label={item} />)}
            </ul>
          </div>
        </TabsContent>
        <TabsContent value="studio" className="mt-5">
          <ContentStudio />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ChecklistRow({ label }: { label: string }) {
  const [done, setDone] = useState(false);
  return (
    <li>
      <button onClick={() => setDone((d) => !d)} className="flex w-full items-center gap-3 rounded-xl border bg-background p-3 text-left transition hover:border-primary/40">
        <div className={`grid h-6 w-6 place-items-center rounded-full ${done ? "bg-primary text-primary-foreground" : "border-2 border-muted"}`}>
          {done && <Check className="h-3.5 w-3.5" />}
        </div>
        <span className={`flex-1 text-sm font-medium ${done ? "line-through text-muted-foreground" : ""}`}>{label}</span>
      </button>
    </li>
  );
}

function ContentStudio() {
  const { user, session } = useAuth();
  const { data: business } = useMyBusiness(user?.id);
  const generate = useServerFn(generateGbpContent);
  const [kind, setKind] = useState<"post" | "description" | "faq" | "service">("post");
  const [tone, setTone] = useState<"friendly" | "professional" | "bold">("friendly");
  const [output, setOutput] = useState("");
  const [busy, setBusy] = useState(false);

  const run = async () => {
    if (!business || !session?.access_token) return;
    setBusy(true); setOutput("");
    try {
      const res = await generate({ data: { accessToken: session.access_token, businessId: business.id, kind, tone } });
      setOutput(res.text);
    } catch (e: any) { toast.error(e.message ?? "Generation failed"); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-3xl border bg-card p-5">
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs font-bold uppercase tracking-wider text-muted-foreground">Generate</label>
            <Select value={kind} onValueChange={(v) => setKind(v as any)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="post">4 GBP posts</SelectItem>
                <SelectItem value="description">Business description</SelectItem>
                <SelectItem value="faq">8 FAQs</SelectItem>
                <SelectItem value="service">6 service descriptions</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="mb-1 block text-xs font-bold uppercase tracking-wider text-muted-foreground">Tone</label>
            <Select value={tone} onValueChange={(v) => setTone(v as any)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="friendly">Friendly</SelectItem>
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="bold">Bold</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <Button onClick={run} disabled={busy} className="mt-4 rounded-full">
          <Sparkles className="mr-2 h-4 w-4" /> {busy ? "Writing…" : "Generate with AI"}
        </Button>
      </div>

      {output && (
        <div className="rounded-3xl border bg-card p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-semibold">Your draft</h3>
            <Button size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(output); toast.success("Copied!"); }}>
              <Copy className="mr-2 h-3 w-3" /> Copy
            </Button>
          </div>
          <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">{output}</pre>
        </div>
      )}
    </div>
  );
}
