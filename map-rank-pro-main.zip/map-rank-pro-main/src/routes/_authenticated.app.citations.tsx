import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Globe, Copy, ExternalLink, Check, Search } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/app/citations")({
  head: () => ({ meta: [{ title: "Citations · Local Growth OS" }] }),
  component: CitationsPage,
});

type Dir = { name: string; url: string; tier: "core" | "social" | "industry"; notes: string };

const CORE: Dir[] = [
  { name: "Google Business Profile", url: "https://business.google.com/", tier: "core", notes: "The single most important listing. Claim and complete every field." },
  { name: "Bing Places", url: "https://www.bingplaces.com/", tier: "core", notes: "Powers Bing Maps and DuckDuckGo. Free import from Google." },
  { name: "Apple Business Connect", url: "https://businessconnect.apple.com/", tier: "core", notes: "Reach iPhone users on Apple Maps and Siri. Free." },
  { name: "Facebook Page", url: "https://www.facebook.com/business/pages", tier: "core", notes: "Local discovery and social proof in one place." },
  { name: "Yelp for Business", url: "https://biz.yelp.com/", tier: "core", notes: "Strong signal in many regions. Add photos and respond to reviews." },
  { name: "Foursquare for Business", url: "https://business.foursquare.com/", tier: "core", notes: "Powers many apps including Apple Maps and Snap." },
  { name: "TripAdvisor", url: "https://www.tripadvisor.com/Owners", tier: "core", notes: "Critical if you serve travelers or food and drink." },
  { name: "Better Business Bureau", url: "https://www.bbb.org/get-listed", tier: "core", notes: "Trust signal for North American audiences." },
];

const SOCIAL: Dir[] = [
  { name: "Instagram Business", url: "https://business.instagram.com/", tier: "social", notes: "Visual proof. Tag your city in your bio." },
  { name: "LinkedIn Company Page", url: "https://www.linkedin.com/company/setup/new/", tier: "social", notes: "Helps with branded search. Free." },
  { name: "Pinterest Business", url: "https://business.pinterest.com/", tier: "social", notes: "Strong for home services, beauty, food." },
  { name: "Nextdoor Business", url: "https://business.nextdoor.com/", tier: "social", notes: "Hyper local recommendations. Free starter." },
  { name: "YouTube Channel", url: "https://www.youtube.com/account", tier: "social", notes: "Owns long tail and video search." },
];

const INDUSTRY: Dir[] = [
  { name: "Healthgrades", url: "https://www.healthgrades.com/", tier: "industry", notes: "For clinics and medical practices." },
  { name: "Avvo", url: "https://www.avvo.com/", tier: "industry", notes: "For lawyers and legal services." },
  { name: "Zillow", url: "https://www.zillow.com/agent-resources/", tier: "industry", notes: "For real estate agents and brokers." },
  { name: "Houzz", url: "https://www.houzz.com/", tier: "industry", notes: "For interior design and home renovation." },
  { name: "OpenTable", url: "https://restaurant.opentable.com/", tier: "industry", notes: "For restaurants and bars." },
  { name: "Booksy or Fresha", url: "https://booksy.com/biz/en-us", tier: "industry", notes: "For salons and barbers." },
  { name: "Angi (formerly Angie's List)", url: "https://www.angi.com/", tier: "industry", notes: "For home service pros." },
  { name: "Thumbtack Pro", url: "https://www.thumbtack.com/pro/", tier: "industry", notes: "For freelancers and local pros." },
];

function CitationsPage() {
  const { user } = useAuth();
  const { data: b } = useMyBusiness(user?.id);
  const [done, setDone] = useState<Record<string, boolean>>({});
  const [q, setQ] = useState("");

  const all = useMemo(() => [...CORE, ...SOCIAL, ...INDUSTRY], []);
  const filtered = useMemo(
    () => (q ? all.filter((d) => d.name.toLowerCase().includes(q.toLowerCase())) : all),
    [all, q],
  );
  const completed = Object.values(done).filter(Boolean).length;

  if (!b) return null;

  const nap = `${b.name}\n${b.city}, ${b.country}\n${b.website ?? ""}`;

  const copyNap = () => {
    navigator.clipboard.writeText(nap);
    toast.success("Name, address, website copied");
  };

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Citations</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">Show up everywhere customers look</h1>
        <p className="mt-2 text-base text-foreground/80">
          Citations are mentions of your business name, address, and website across the web. Consistency builds trust with
          Google. Tick each one off as you claim and verify it.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-[1fr_280px]">
        <div className="rounded-3xl border bg-card p-5">
          <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Your reusable info</div>
          <pre className="mt-2 whitespace-pre-wrap rounded-2xl bg-secondary/50 p-3 font-sans text-sm leading-relaxed">
{nap}
          </pre>
          <Button onClick={copyNap} variant="outline" size="sm" className="mt-3 rounded-full">
            <Copy className="mr-2 h-3.5 w-3.5" /> Copy NAP block
          </Button>
        </div>
        <div className="rounded-3xl border bg-gradient-to-br from-primary/15 to-accent/10 p-5">
          <div className="text-xs font-bold uppercase tracking-wider text-primary">Progress</div>
          <div className="mt-2 font-display text-4xl font-extrabold">
            {completed}
            <span className="text-xl text-muted-foreground"> / {all.length}</span>
          </div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-background/60">
            <div
              className="h-full rounded-full bg-primary transition-all"
              style={{ width: `${(completed / all.length) * 100}%` }}
            />
          </div>
          <p className="mt-3 text-xs text-foreground/80">Aim for all 8 core directories first.</p>
        </div>
      </div>

      <div className="relative">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search directories" className="pl-10 h-11 rounded-2xl" />
      </div>

      {(["core", "social", "industry"] as const).map((tier) => {
        const list = filtered.filter((d) => d.tier === tier);
        if (!list.length) return null;
        const titleMap = { core: "Core directories", social: "Social profiles", industry: "Industry specific" };
        return (
          <section key={tier}>
            <h2 className="mb-3 font-display text-lg font-bold">{titleMap[tier]}</h2>
            <div className="grid gap-3 sm:grid-cols-2">
              {list.map((d) => {
                const isDone = !!done[d.name];
                return (
                  <div key={d.name} className="rounded-2xl border bg-card p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary/10 text-primary">
                          <Globe className="h-4 w-4" />
                        </div>
                        <div>
                          <div className="font-semibold leading-tight">{d.name}</div>
                          <Badge variant="secondary" className="mt-1 text-[10px] capitalize">
                            {tier}
                          </Badge>
                        </div>
                      </div>
                      <button
                        onClick={() => setDone({ ...done, [d.name]: !isDone })}
                        className={`grid h-7 w-7 shrink-0 place-items-center rounded-full transition ${
                          isDone ? "bg-primary text-primary-foreground" : "border-2 border-muted hover:border-primary"
                        }`}
                        aria-label="Toggle complete"
                      >
                        {isDone && <Check className="h-4 w-4" />}
                      </button>
                    </div>
                    <p className="mt-2 text-sm text-foreground/75">{d.notes}</p>
                    <a
                      href={d.url}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline"
                    >
                      Open and claim <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                );
              })}
            </div>
          </section>
        );
      })}
    </div>
  );
}
