import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, Trophy, Star, AlertTriangle, Lightbulb, Plus, X } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { analyzeCompetitors } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/app/competitors")({
  head: () => ({ meta: [{ title: "Competitors · Local Growth OS" }] }),
  component: CompetitorsPage,
});

type Result = Awaited<ReturnType<typeof analyzeCompetitors>>;

function CompetitorsPage() {
  const { user, session } = useAuth();
  const { data: b } = useMyBusiness(user?.id);
  const analyze = useServerFn(analyzeCompetitors);
  const [names, setNames] = useState<string[]>([""]);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  const run = async () => {
    if (!b || !session?.access_token) return;
    setBusy(true);
    try {
      const filtered = names.map((n) => n.trim()).filter(Boolean);
      const out = await analyze({
        data: { accessToken: session.access_token, businessId: b.id, competitorNames: filtered },
      });
      setResult(out);
      toast.success("Competitive landscape ready");
    } catch (e: any) {
      toast.error(e.message ?? "Analysis failed");
    } finally {
      setBusy(false);
    }
  };

  if (!b) return null;

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Competitors</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">Know who you are up against</h1>
        <p className="mt-2 text-base text-foreground/80">
          We use AI to analyze the local landscape for {b.category} businesses in {b.city}. Add up to 5 known competitors,
          or let the system infer the strongest local players.
        </p>
      </div>

      <div className="rounded-3xl border bg-card p-6">
        <h3 className="font-display text-lg font-bold">Add competitor names (optional)</h3>
        <p className="mt-1 text-sm text-foreground/70">Leave empty to let the AI pick the most likely top players.</p>
        <div className="mt-4 space-y-2">
          {names.map((n, i) => (
            <div key={i} className="flex gap-2">
              <Input
                value={n}
                placeholder={`Competitor ${i + 1} name`}
                onChange={(e) => setNames(names.map((x, j) => (i === j ? e.target.value : x)))}
              />
              {names.length > 1 && (
                <Button variant="ghost" size="icon" onClick={() => setNames(names.filter((_, j) => j !== i))}>
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
          {names.length < 5 && (
            <Button variant="outline" size="sm" className="rounded-full" onClick={() => setNames([...names, ""])}>
              <Plus className="mr-2 h-4 w-4" /> Add competitor
            </Button>
          )}
        </div>
        <Button onClick={run} disabled={busy} className="mt-5 rounded-full">
          <Sparkles className="mr-2 h-4 w-4" />
          {busy ? "Analyzing the landscape…" : "Run competitor analysis"}
        </Button>
      </div>

      {result && (
        <>
          <div className="rounded-3xl border bg-gradient-to-br from-primary/10 to-accent/10 p-6">
            <div className="text-xs font-bold uppercase tracking-wider text-primary">Positioning summary</div>
            <p className="mt-2 text-base leading-relaxed text-foreground/90">{result.positioning_summary}</p>
            <div className="mt-5">
              <div className="text-xs font-bold uppercase tracking-wider text-primary">Three quick wins</div>
              <ul className="mt-2 space-y-2">
                {result.three_quick_wins.map((w, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                    <span>{w}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {result.competitors.map((c, i) => (
              <div key={i} className="rounded-3xl border bg-card p-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary/15 text-primary">
                      <Trophy className="h-4 w-4" />
                    </div>
                    <h4 className="font-display text-base font-bold">{c.name}</h4>
                  </div>
                  <Badge
                    className={
                      c.threat_level === "high"
                        ? "bg-destructive/15 text-destructive border-0"
                        : c.threat_level === "medium"
                        ? "bg-accent/20 text-accent-foreground border-0"
                        : "bg-success/15 text-success-foreground border-0"
                    }
                  >
                    {c.threat_level} threat
                  </Badge>
                </div>
                <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Star className="h-3 w-3 fill-accent text-accent" />
                    {c.estimated_rating.toFixed(1)} approx
                  </span>
                  <span>{c.estimated_review_count} reviews approx</span>
                </div>
                <Section title="Strengths" items={c.strengths} icon={Trophy} tone="primary" />
                <Section title="Weaknesses" items={c.weaknesses} icon={AlertTriangle} tone="destructive" />
                <Section title="Your opportunity" items={c.opportunities_for_you} icon={Lightbulb} tone="accent" />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function Section({
  title,
  items,
  icon: Icon,
  tone,
}: {
  title: string;
  items: string[];
  icon: any;
  tone: "primary" | "destructive" | "accent";
}) {
  const color =
    tone === "primary"
      ? "text-primary"
      : tone === "destructive"
      ? "text-destructive"
      : "text-accent-foreground";
  return (
    <div className="mt-4">
      <div className={`flex items-center gap-2 text-xs font-bold uppercase tracking-wider ${color}`}>
        <Icon className="h-3.5 w-3.5" /> {title}
      </div>
      <ul className="mt-1.5 space-y-1 text-sm text-foreground/80">
        {items.map((i, idx) => (
          <li key={idx} className="leading-snug">
            • {i}
          </li>
        ))}
      </ul>
    </div>
  );
}
