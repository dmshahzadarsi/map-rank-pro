import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, FileText, Download, TrendingUp, AlertTriangle, Calendar, Target } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { generateReport } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/app/reports")({
  head: () => ({ meta: [{ title: "Reports · Local Growth OS" }] }),
  component: ReportsPage,
});

type Result = Awaited<ReturnType<typeof generateReport>>;

function ReportsPage() {
  const { user, session } = useAuth();
  const { data: b } = useMyBusiness(user?.id);
  const run = useServerFn(generateReport);
  const [busy, setBusy] = useState(false);
  const [out, setOut] = useState<Result | null>(null);

  const fire = async () => {
    if (!b || !session?.access_token) return;
    setBusy(true);
    try {
      const res = await run({ data: { accessToken: session.access_token, businessId: b.id } });
      setOut(res);
      toast.success("Report ready");
    } catch (e: any) {
      toast.error(e.message ?? "Failed to generate report");
    } finally {
      setBusy(false);
    }
  };

  const download = () => {
    if (!out || !b) return;
    const md = `# Monthly Growth Report
${b.name} · ${b.city}, ${b.country}
Generated ${new Date().toLocaleDateString()}

## Executive summary
${out.executive_summary}

## Growth score commentary
${out.growth_score_commentary}

## What went well
${out.what_went_well.map((x) => `- ${x}`).join("\n")}

## What to fix
${out.what_to_fix.map((x) => `- ${x}`).join("\n")}

## Next 30 days
${out.next_30_days_plan
  .map((w) => `### Week ${w.week} · ${w.focus}\n${w.actions.map((a) => `- ${a}`).join("\n")}`)
  .join("\n\n")}

## Expected impact
${out.expected_impact}
`;
    const blob = new Blob([md], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${b.name.replace(/\s+/g, "-").toLowerCase()}-growth-report.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!b) return null;

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Reports</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">Your monthly growth report</h1>
        <p className="mt-2 text-base text-foreground/80">
          A clear, owner friendly read out of where you stand and exactly what to do next 30 days. Generate fresh anytime.
        </p>
      </div>

      <div className="rounded-3xl border bg-gradient-to-br from-primary/10 to-accent/10 p-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="font-display text-xl font-bold">Generate this month's report</div>
            <p className="mt-1 text-sm text-foreground/80">
              Uses your current Growth Score, reviews, photos, and goals.
            </p>
          </div>
          <div className="flex gap-2">
            <Button onClick={fire} disabled={busy} className="rounded-full">
              <Sparkles className="mr-2 h-4 w-4" />
              {busy ? "Writing…" : out ? "Regenerate" : "Generate report"}
            </Button>
            {out && (
              <Button variant="outline" onClick={download} className="rounded-full">
                <Download className="mr-2 h-4 w-4" /> Download
              </Button>
            )}
          </div>
        </div>
      </div>

      {out && (
        <div className="space-y-5">
          <Card icon={FileText} title="Executive summary" tone="primary">
            <p className="text-base leading-relaxed">{out.executive_summary}</p>
          </Card>

          <Card icon={TrendingUp} title="Growth score commentary" tone="primary">
            <p className="text-base leading-relaxed">{out.growth_score_commentary}</p>
          </Card>

          <div className="grid gap-5 md:grid-cols-2">
            <Card icon={TrendingUp} title="What went well" tone="primary">
              <ul className="space-y-2 text-sm">
                {out.what_went_well.map((x, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="text-primary">•</span> {x}
                  </li>
                ))}
              </ul>
            </Card>
            <Card icon={AlertTriangle} title="What to fix" tone="accent">
              <ul className="space-y-2 text-sm">
                {out.what_to_fix.map((x, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="text-accent">•</span> {x}
                  </li>
                ))}
              </ul>
            </Card>
          </div>

          <Card icon={Calendar} title="Next 30 days plan" tone="primary">
            <div className="grid gap-3 sm:grid-cols-2">
              {out.next_30_days_plan.map((w) => (
                <div key={w.week} className="rounded-2xl border bg-background p-4">
                  <div className="text-xs font-bold uppercase tracking-wider text-primary">Week {w.week}</div>
                  <div className="mt-1 font-semibold">{w.focus}</div>
                  <ul className="mt-2 space-y-1 text-sm text-foreground/80">
                    {w.actions.map((a, i) => (
                      <li key={i}>• {a}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </Card>

          <Card icon={Target} title="Expected impact" tone="accent">
            <p className="text-base leading-relaxed">{out.expected_impact}</p>
          </Card>
        </div>
      )}

      {!out && !busy && (
        <div className="rounded-3xl border-2 border-dashed bg-card p-12 text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-primary/15 text-primary">
            <FileText className="h-7 w-7" />
          </div>
          <h3 className="mt-4 font-display text-xl font-bold">No report yet</h3>
          <p className="mt-1 text-sm text-foreground/70">Click Generate to create your first monthly report.</p>
        </div>
      )}
    </div>
  );
}

function Card({
  icon: Icon,
  title,
  children,
  tone,
}: {
  icon: any;
  title: string;
  children: React.ReactNode;
  tone: "primary" | "accent";
}) {
  return (
    <div className="rounded-3xl border bg-card p-6">
      <div className="flex items-center gap-3">
        <div className={`grid h-9 w-9 place-items-center rounded-xl ${tone === "primary" ? "bg-primary/15 text-primary" : "bg-accent/15 text-accent-foreground"}`}>
          <Icon className="h-4 w-4" />
        </div>
        <h3 className="font-display text-lg font-bold">{title}</h3>
      </div>
      <div className="mt-4">{children}</div>
    </div>
  );
}
