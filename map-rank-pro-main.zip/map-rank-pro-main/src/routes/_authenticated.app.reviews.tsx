import { useState, useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import QRCode from "qrcode";
import { Copy, Sparkles, MessageSquare, QrCode, Mail } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { generateReviewReply } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/app/reviews")({
  head: () => ({ meta: [{ title: "Reviews, Local Growth OS" }] }),
  component: ReviewsPage,
});

function ReviewsPage() {
  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Reviews</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">Get more 5-star reviews</h1>
      </div>
      <Tabs defaultValue="request">
        <TabsList className="rounded-full">
          <TabsTrigger value="request" className="rounded-full">Request reviews</TabsTrigger>
          <TabsTrigger value="reply" className="rounded-full">AI reply generator</TabsTrigger>
        </TabsList>
        <TabsContent value="request" className="mt-5"><RequestStudio /></TabsContent>
        <TabsContent value="reply" className="mt-5"><ReplyStudio /></TabsContent>
      </Tabs>
    </div>
  );
}

function RequestStudio() {
  const { user } = useAuth();
  const { data: b } = useMyBusiness(user?.id);
  const [qrUrl, setQrUrl] = useState<string>("");
  const link = b?.gbp_url || "https://g.page/r/your-business/review";

  useEffect(() => {
    QRCode.toDataURL(link, { width: 360, margin: 2, color: { dark: "#1c1917" } }).then(setQrUrl);
  }, [link]);

  if (!b) return null;

  const wa = `https://wa.me/?text=${encodeURIComponent(`Hi! Thanks for visiting ${b.name}. Could you take 30 seconds to leave us a Google review? It really helps us out: ${link}`)}`;
  const sms = `Hi! Thanks for visiting ${b.name}. Could you take 30 seconds to leave us a Google review? ${link}`;
  const email = `Subject: Thank you from ${b.name}\n\nHi,\n\nThanks for choosing ${b.name}. Reviews help small businesses like ours stay visible to other locals, would you mind sharing a quick one?\n\n${link}\n\nThank you!\n${b.name}`;

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <div className="rounded-3xl border bg-card p-5">
        <div className="flex items-center gap-2 text-sm font-bold"><QrCode className="h-4 w-4 text-primary" /> Branded QR code</div>
        <p className="mt-1 text-sm text-foreground/70">Print this for your reception desk.</p>
        {qrUrl && (
          <>
            <img src={qrUrl} alt="Review QR code" className="mx-auto mt-4 h-56 w-56 rounded-2xl border" />
            <a href={qrUrl} download={`${b.name}-review-qr.png`} className="mt-3 block">
              <Button variant="outline" className="w-full rounded-full">Download PNG</Button>
            </a>
          </>
        )}
      </div>

      <div className="space-y-4">
        <TemplateCard icon={MessageSquare} title="WhatsApp message" body={`Hi! Thanks for visiting ${b.name}...`}>
          <a href={wa} target="_blank" rel="noreferrer">
            <Button className="w-full rounded-full bg-success text-success-foreground hover:bg-success/90">Open in WhatsApp</Button>
          </a>
        </TemplateCard>
        <TemplateCard icon={MessageSquare} title="SMS template" body={sms} />
        <TemplateCard icon={Mail} title="Email template" body={email} />
      </div>
    </div>
  );
}

function TemplateCard({ icon: Icon, title, body, children }: { icon: any; title: string; body: string; children?: React.ReactNode }) {
  return (
    <div className="rounded-2xl border bg-card p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-bold"><Icon className="h-4 w-4 text-primary" /> {title}</div>
        <Button size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(body); toast.success("Copied"); }}>
          <Copy className="h-3 w-3" />
        </Button>
      </div>
      <pre className="mt-2 whitespace-pre-wrap font-sans text-xs text-foreground/70">{body}</pre>
      {children && <div className="mt-3">{children}</div>}
    </div>
  );
}

function ReplyStudio() {
  const { user, session } = useAuth();
  const { data: b } = useMyBusiness(user?.id);
  const generate = useServerFn(generateReviewReply);
  const [text, setText] = useState("");
  const [rating, setRating] = useState(5);
  const [tone, setTone] = useState<"friendly" | "professional" | "bold">("friendly");
  const [out, setOut] = useState("");
  const [busy, setBusy] = useState(false);

  const run = async () => {
    if (!b || !session?.access_token || !text.trim()) return;
    setBusy(true); setOut("");
    try {
      const res = await generate({ data: { accessToken: session.access_token, businessId: b.id, reviewText: text, rating, tone } });
      setOut(res.text);
    } catch (e: any) { toast.error(e.message ?? "Failed"); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-3xl border bg-card p-5 space-y-3">
        <div className="space-y-1.5">
          <Label>Paste the customer's review</Label>
          <Textarea rows={4} value={text} onChange={(e) => setText(e.target.value)} placeholder="The service was great but..." />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label>Star rating</Label>
            <Input type="number" min={1} max={5} value={rating} onChange={(e) => setRating(Number(e.target.value))} />
          </div>
          <div className="space-y-1.5">
            <Label>Tone</Label>
            <Select value={tone} onValueChange={(v) => setTone(v as any)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="friendly">Friendly</SelectItem>
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="bold">Bold</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <Button onClick={run} disabled={busy || !text.trim()} className="rounded-full">
          <Sparkles className="mr-2 h-4 w-4" /> {busy ? "Writing…" : "Generate 3 replies"}
        </Button>
      </div>
      {out && (
        <div className="rounded-3xl border bg-card p-5">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="font-semibold">Replies</h3>
            <Button size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(out); toast.success("Copied"); }}>
              <Copy className="mr-2 h-3 w-3" /> Copy all
            </Button>
          </div>
          <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">{out}</pre>
        </div>
      )}
    </div>
  );
}
