import { useEffect, useRef } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { Send, Sparkles } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useMyBusiness } from "@/hooks/useBusiness";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/app/coach")({
  head: () => ({ meta: [{ title: "AI Coach, Local Growth OS" }] }),
  component: CoachPage,
});

function CoachPage() {
  const { session } = useAuth();
  const { user } = useAuth();
  const { data: business } = useMyBusiness(user?.id);

  const transport = new DefaultChatTransport({
    api: "/api/chat",
    headers: () => ({ Authorization: `Bearer ${session?.access_token ?? ""}` }),
    body: () => ({ businessId: business?.id }),
  });

  const { messages, sendMessage, status } = useChat({ transport });
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const submit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const v = inputRef.current?.value.trim();
    if (!v || !business) return;
    sendMessage({ text: v });
    if (inputRef.current) inputRef.current.value = "";
  };

  if (!business) return null;

  return (
    <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-3xl flex-col">
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">AI Coach</div>
        <h1 className="mt-1 font-display text-3xl font-extrabold">Ask anything about your growth</h1>
      </div>

      <div ref={scrollRef} className="mt-6 flex-1 overflow-y-auto rounded-3xl border bg-card p-5">
        {messages.length === 0 && (
          <div className="grid h-full place-items-center text-center">
            <div>
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-primary text-primary-foreground">
                <Sparkles className="h-7 w-7" />
              </div>
              <h3 className="mt-4 font-display text-lg font-bold">Your AI Growth Coach</h3>
              <p className="mt-1 max-w-sm text-sm text-foreground/70">
                Knows {business.name}, your score, and your tasks. Ask anything.
              </p>
              <div className="mt-4 flex flex-wrap justify-center gap-2 text-xs">
                {["What should I do first?", "How do I get more reviews?", "Why isn't my GBP ranking?"].map((q) => (
                  <button key={q} onClick={() => sendMessage({ text: q })} className="rounded-full border bg-background px-3 py-1.5 hover:border-primary">{q}</button>
                ))}
              </div>
            </div>
          </div>
        )}
        <div className="space-y-4">
          {messages.map((m) => {
            const text = m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
            return (
              <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[85%] whitespace-pre-wrap text-sm leading-relaxed ${m.role === "user" ? "rounded-2xl bg-primary px-4 py-2.5 text-primary-foreground" : "text-foreground"}`}>
                  {text}
                </div>
              </div>
            );
          })}
          {(status === "submitted" || status === "streaming") && messages[messages.length - 1]?.role === "user" && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Sparkles className="h-4 w-4 animate-pulse text-primary" /> Thinking…
            </div>
          )}
        </div>
      </div>

      <form onSubmit={submit} className="mt-4 flex gap-2">
        <Textarea
          ref={inputRef}
          rows={1}
          placeholder="Ask your coach…"
          className="resize-none rounded-2xl"
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); }
          }}
        />
        <Button type="submit" size="icon" className="h-11 w-11 shrink-0 rounded-2xl">
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}
