import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Business = Database["public"]["Tables"]["businesses"]["Row"];

export function useMyBusiness(userId: string | undefined) {
  return useQuery({
    queryKey: ["business", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("businesses")
        .select("*")
        .eq("owner_id", userId!)
        .maybeSingle();
      if (error) throw error;
      return data as Business | null;
    },
  });
}
