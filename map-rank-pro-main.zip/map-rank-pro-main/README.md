<div align="center">

# Local Growth OS

**A local-business growth operating system, not just another SEO dashboard.**

Turn a real consultant's local-SEO playbook into a weekly action plan — with a Growth Score,
real Google data, an AI coach, and revenue-impact tracking — so a non-technical business owner
can improve their Google Maps visibility in under 10 minutes a day.

[![License: MIT](https://img.shields.io/badge/License-MIT-16a34a.svg)](./LICENSE)
[![Made with TanStack Start](https://img.shields.io/badge/TanStack-Start-16a34a.svg)](https://tanstack.com/start)
[![Deploys to Cloudflare Workers](https://img.shields.io/badge/Deploy-Cloudflare%20Workers-f38020.svg)](https://developers.cloudflare.com/workers/)

**Live demo:** [app.shahzadarsi.com](https://app.shahzadarsi.com)

</div>

---

## Table of contents

- [Why this exists](#why-this-exists)
- [Features](#features)
- [Screenshots](#screenshots)
- [Tech stack](#tech-stack)
- [Getting started](#getting-started)
- [Environment variables](#environment-variables)
- [Database setup](#database-setup)
- [Running locally](#running-locally)
- [Deployment](#deployment)
- [Project structure](#project-structure)
- [Design principles](#design-principles)
- [Roadmap](#roadmap)
- [Contributing](#contributing)
- [License](#license)

---

## Why this exists

Most "local SEO tools" throw a wall of metrics at a business owner and leave them to figure out
what to do. Local Growth OS flips that: it answers one question every morning — **"what should I
do next?"** — and shows the owner the impact of doing it.

A guiding rule runs through the whole codebase: **no fake data.** Every ranking, competitor, and
recommendation is derived from real data (the owner's live Google Business Profile via the Google
Places API, their own inputs, or their historical activity). Where a number is an estimate, the
formula is shown and adjustable. Nothing is invented to look impressive.

## Features

| Area | What it does | Data source |
|------|--------------|-------------|
| **Growth Score** | A single 0–100 score with a per-factor breakdown and category sub-scores; recorded over time. | Deterministic scoring of the business profile |
| **Weekly Tasks** | AI-generated, business-specific action plan; completing a task awards XP + score and rolls a streak. Free plan is capped at 3 completions/day. | AI (Anthropic or Gemini) grounded in real profile data |
| **Real Google data** | One-click sync pulls the exact live rating + review count from the owner's listing (resolved from a Google Maps share link). | Google Places API (New) |
| **Competitors** | The real top same-category businesses nearby, with live ratings/review counts and a gap analysis; weekly velocity snapshots. | Google Places API (New) |
| **Rank tracking** | Real position for chosen keywords, measured live from a 9-point geo-grid across the owner's area, with a trend over time. | Google Places API (New) |
| **GBP audit** | A live audit of the actual Google Business Profile (website, phone, hours, photos, category, rating, reviews) with a completeness score. | Google Places Details |
| **Revenue Impact** | Turns owner-entered activity (calls, directions, clicks, appointments, average customer value) into an estimated revenue-influenced / ROI / month-over-month view with a transparent, editable formula. | Owner inputs |
| **AI Coach** | Chat that knows the business, its score, and its tasks — plus a rule-based recommendation engine ("what to do next"). | Real profile + history data |
| **AI Content** | Generates Google Posts, descriptions, FAQs, service copy, and marketing pieces. | AI |
| **Content Library** | Searchable, editable, duplicable, archivable store of everything generated. | Stored generations |
| **Reports** | Consultant-grade monthly report with a per-action value breakdown, exportable as a branded PDF. | Real profile + score + competitor gap |
| **Action History** | A full log of completed actions with date/time, score gained, and XP. | Task history |
| **Academy** | A no-fluff local-SEO lesson library with per-step "how" and "why". | Static, expert-written |

## Screenshots

> Add your own screenshots to `docs/screenshots/` and they'll render below.
> (Or see the features live at **[app.shahzadarsi.com](https://app.shahzadarsi.com)**.)

| Dashboard | Growth Score | Revenue Impact |
|-----------|--------------|----------------|
| ![Dashboard](docs/screenshots/dashboard.png) | ![Growth Score](docs/screenshots/score.png) | ![Revenue Impact](docs/screenshots/revenue.png) |

| Competitors | Rank tracking | Monthly report (PDF) |
|-------------|---------------|----------------------|
| ![Competitors](docs/screenshots/competitors.png) | ![Rankings](docs/screenshots/rankings.png) | ![Report](docs/screenshots/report.png) |

## Tech stack

- **Framework:** [TanStack Start](https://tanstack.com/start) (React 19 + Vite, SSR) with
  [TanStack Router](https://tanstack.com/router) and [TanStack Query](https://tanstack.com/query)
- **Language:** TypeScript (strict)
- **Styling:** Tailwind CSS v4 + [shadcn/ui](https://ui.shadcn.com) (Radix primitives), theme-aware (light/dark)
- **Backend / DB / Auth:** [Supabase](https://supabase.com) (Postgres + Row Level Security + Auth)
- **AI:** [Vercel AI SDK](https://sdk.vercel.ai) with a pluggable provider — Anthropic (Claude) or Google (Gemini)
- **Real Google data:** Google Places API (New)
- **Charts / PDF:** Recharts, jsPDF
- **Hosting:** Cloudflare Workers (SSR + static assets) via Wrangler

## Getting started

### Prerequisites

- **Node.js 20+** (or [Bun](https://bun.sh))
- A **Supabase** project (free tier is fine)
- An **AI provider key** — Anthropic *or* a free Google Gemini key
- A **Google Places API (New)** key (only needed for the live-Google-data features)

### Install

```bash
git clone https://github.com/<your-org>/local-growth-os.git
cd local-growth-os
npm install        # or: bun install
```

## Environment variables

Copy the example file and fill it in:

```bash
cp .env.example .env
```

| Variable | Required | Purpose |
|----------|:--------:|---------|
| `SUPABASE_URL` / `VITE_SUPABASE_URL` | ✅ | Your Supabase project URL |
| `SUPABASE_PUBLISHABLE_KEY` / `VITE_SUPABASE_PUBLISHABLE_KEY` | ✅ | Supabase anon/publishable key |
| `VITE_SUPABASE_PROJECT_ID` | ✅ | Supabase project ref |
| `SUPABASE_SERVICE_ROLE_KEY` | ✅ | Server-only. Powers all AI features + secure server functions. **Never commit.** |
| `ANTHROPIC_API_KEY` **or** `GOOGLE_GENERATIVE_AI_API_KEY` | ✅ (one) | AI provider. Precedence: Anthropic → Google. |
| `ANTHROPIC_MODEL` / `GOOGLE_MODEL` | ⬜ | Optional model overrides |
| `GOOGLE_PLACES_API_KEY` | ⬜ | Enables live rating/review sync, competitors, rank tracking, GBP audit |
| `ADMIN_EMAILS` | ⬜ | Comma-separated emails granted admin access (`/app/admin`) |

`VITE_*` values are baked into the client bundle at build time; the rest are server-only secrets.
In production, set the server secrets with `wrangler secret put` rather than committing them.

## Database setup

Run the SQL migrations in `supabase/migrations/` **in filename order** using the Supabase SQL
Editor (Dashboard → SQL Editor). They create the schema, Row Level Security policies, and the
server-side functions that enforce plan limits. Then, under Authentication → URL Configuration,
add your site URL and an `…/onboarding` redirect URL.

## Running locally

```bash
npm run dev        # start the dev server (Vite)
```

Open the printed local URL, create an account, and complete onboarding by pasting a Google
Business Profile share link.

Other scripts:

```bash
npm run build      # production build (client + SSR worker)
npm run lint       # eslint
npm run format     # prettier --write
```

## Deployment

The app builds to a Cloudflare Worker (SSR) plus static assets.

```bash
npx wrangler login                                   # one-time
# set each server secret on the deployed worker:
npx wrangler secret put SUPABASE_URL                 -c wrangler.deploy.jsonc
npx wrangler secret put SUPABASE_PUBLISHABLE_KEY     -c wrangler.deploy.jsonc
npx wrangler secret put SUPABASE_SERVICE_ROLE_KEY    -c wrangler.deploy.jsonc
npx wrangler secret put GOOGLE_GENERATIVE_AI_API_KEY -c wrangler.deploy.jsonc
npx wrangler secret put GOOGLE_PLACES_API_KEY        -c wrangler.deploy.jsonc
npx wrangler secret put ADMIN_EMAILS                 -c wrangler.deploy.jsonc

npm run deploy     # = vite build && wrangler deploy -c wrangler.deploy.jsonc
```

For CI, set `CLOUDFLARE_API_TOKEN` (Workers Scripts: Edit) and `CLOUDFLARE_ACCOUNT_ID` in the
environment instead of `wrangler login`.

## Project structure

```
src/
  routes/            # file-based routes (TanStack Router). _authenticated.app.* are the app pages
  lib/               # server functions (*.functions.ts), scoring, AI gateway, Places client
  components/        # UI + app shell (shadcn/ui in components/ui)
  integrations/      # Supabase client (browser + server)
  hooks/             # auth + business data hooks
supabase/migrations/ # ordered SQL migrations (schema, RLS, functions)
```

Server functions (in `src/lib/*.functions.ts`) run on the server, verify ownership, and use the
Supabase service role — the browser never sees privileged keys.

## Design principles

1. **No fake data.** Real Google data, real user inputs, or an explicit, adjustable estimate — never invented numbers.
2. **Answer "what should I do next?"** Every screen points to a clear next action.
3. **Fast & minimal.** No clutter, no vanity metrics.
4. **Secure by default.** Row Level Security, ownership checks in every server function, secrets kept server-side.
5. **Mobile responsive & dark-mode compatible** throughout.

## Roadmap

**Shipped**
- [x] Growth Score + weekly AI tasks + streaks/XP
- [x] Real Google data (sync, competitors, geo-grid rank tracking, GBP audit)
- [x] AI Coach + rule-based recommendations
- [x] AI content + Content Library
- [x] Consultant-grade monthly reports (PDF)
- [x] Revenue Impact dashboard
- [x] Action History

**Next**
- [ ] **Google Business Profile OAuth** — auto-pull reviews & performance metrics; post directly to GBP (requires Google API verification)
- [ ] **Review management** — fetch/store reviews, sentiment + issue classification, AI reply drafts (approval-gated)
- [ ] **Post scheduler + calendar** — draft → schedule → publish
- [ ] **Notifications** — in-app + email (new review, task due, competitor change)
- [ ] **Payments webhooks** — auto-activate paid plans
- [ ] **Team members & role-based permissions**
- [ ] **Error tracking + product analytics**

## Contributing

Contributions are welcome! Please read **[CONTRIBUTING.md](./CONTRIBUTING.md)** and our
**[Code of Conduct](./CODE_OF_CONDUCT.md)** before opening an issue or pull request.

## License

Released under the [MIT License](./LICENSE). © 2026 Shahzad Arsi.
