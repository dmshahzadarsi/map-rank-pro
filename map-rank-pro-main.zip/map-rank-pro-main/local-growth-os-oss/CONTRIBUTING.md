# Contributing to Local Growth OS

First off — thank you for taking the time to contribute! This project aims to be a genuinely
useful local-business growth tool, and every improvement helps real business owners. This guide
explains how to propose changes so they can be reviewed and merged smoothly.

By participating, you agree to abide by our [Code of Conduct](./CODE_OF_CONDUCT.md).

## Table of contents

- [Ways to contribute](#ways-to-contribute)
- [Ground rules](#ground-rules)
- [Development setup](#development-setup)
- [Branching & commits](#branching--commits)
- [Coding standards](#coding-standards)
- [Submitting a pull request](#submitting-a-pull-request)
- [Reporting bugs](#reporting-bugs)
- [Suggesting features](#suggesting-features)
- [Security issues](#security-issues)

## Ways to contribute

- 🐛 **Report a bug** — open a clear, reproducible issue.
- 💡 **Suggest a feature** — describe the real business problem it solves.
- 📝 **Improve docs** — fix typos, clarify setup steps, add examples.
- 🎨 **Improve UI/UX** — keep it minimal, fast, mobile-responsive, and dark-mode compatible.
- 🔧 **Fix an issue** — comment on an open issue to claim it, then send a PR.

## Ground rules

This project has one non-negotiable principle that applies to every contribution:

> **No fake data.** Every metric, ranking, competitor, or recommendation must come from real data
> — a live API, the user's own inputs, or historical data already in the system. Where a value is
> an estimate, the formula must be visible and adjustable. Never fabricate numbers, competitors,
> reviews, or analytics to make a screen look impressive.

Additionally:

- Every feature should solve a **real business problem** and provide **measurable value**.
- Keep the app **fast**, **minimal**, and **secure** (see [Coding standards](#coding-standards)).
- Prefer **reusing existing components** over adding new dependencies.

## Development setup

See the [README](./README.md#getting-started) for full setup. In short:

```bash
git clone https://github.com/<your-org>/local-growth-os.git
cd local-growth-os
npm install
cp .env.example .env      # fill in your Supabase + AI keys
npm run dev
```

You'll need a Supabase project and at least one AI provider key. The Google Places key is only
required to work on the live-Google-data features.

## Branching & commits

1. Fork the repo and create a feature branch from `main`:
   ```bash
   git checkout -b feat/short-description
   ```
   Use prefixes like `feat/`, `fix/`, `docs/`, `refactor/`, `chore/`.

2. Write clear commit messages. [Conventional Commits](https://www.conventionalcommits.org) are
   encouraged:
   ```
   feat(reports): add month-over-month comparison to PDF
   fix(rankings): correct grid-center rank calculation
   docs: clarify Cloudflare secret setup
   ```

3. Keep PRs focused. One logical change per pull request is much easier to review.

## Coding standards

- **TypeScript, strict.** No `any` unless truly unavoidable (and justified in a comment).
- **Run the checks before pushing** — a PR should be green on all three:
  ```bash
  npx tsc --noEmit     # type-check
  npm run lint         # eslint (also enforces Prettier formatting)
  npm run build        # production build must succeed
  ```
- **Security:** all privileged data access goes through server functions (`src/lib/*.functions.ts`)
  that verify ownership and use the Supabase service role. Never expose service-role keys or
  bypass Row Level Security on the client.
- **Styling:** Tailwind + existing shadcn/ui components. Use theme tokens (`bg-card`,
  `text-foreground`, `text-primary`, …) so light/dark mode both work. Test on mobile widths.
- **Match the surrounding code** — comment density, naming, and idioms.
- If you add a route, run `npm run build` once so the TanStack route tree regenerates before
  type-checking.

## Submitting a pull request

1. Ensure `tsc`, `lint`, and `build` all pass locally.
2. Update docs (README, comments) if your change affects usage or setup.
3. Add or update screenshots in `docs/screenshots/` if you changed a screen.
4. Open the PR against `main` with:
   - **What & why** — the problem and your solution.
   - **How to test** — steps a reviewer can follow.
   - **Screenshots / recordings** for UI changes.
5. Be responsive to review feedback. Maintainers may request changes to keep the codebase
   consistent and the UX simple.

## Reporting bugs

Open an issue with:

- A clear title and description.
- **Steps to reproduce**, expected vs. actual behaviour.
- Environment (OS, browser, Node version) and any console/network errors.
- Screenshots or a short screen recording if it's a UI bug.

Please **do not** include secrets (API keys, service-role keys, access tokens) in issues.

## Suggesting features

Open an issue describing:

- The **real business problem** the feature solves.
- Roughly how it would work and what **real data** it would use.
- Why it belongs in Local Growth OS (fits the "what do I do next?" philosophy).

## Security issues

**Do not open a public issue for security vulnerabilities.** Instead, email the maintainer
privately (see the repository's profile/README contact) with details and reproduction steps.
We'll acknowledge and work on a fix as quickly as possible.

---

Thanks again for helping make local business growth accessible to everyone. 💚
