
# Local Growth OS — v1 Plan

A guided, gamified local-SEO operating system for non-technical business owners. Manual data entry + AI coach. No billing, no rank/citation APIs in v1 — those land later behind clean adapters.

## Stack (already in project)

TanStack Start + Vite + React + Tailwind v4 + shadcn/ui + Lovable Cloud (Supabase) + Lovable AI Gateway (default model: `google/gemini-3-flash-preview`) + Framer Motion + Recharts.

## Brand & visual system

Duolingo-energetic, mobile-first, premium-feeling.

- **Palette** (oklch tokens in `src/styles.css`):
  - Primary: vibrant grass green
  - Accent: warm orange (XP, streaks)
  - Success / Warning / Destructive: green / amber / red
  - Surfaces: off-white light, deep slate dark
- **Type**: Display = Plus Jakarta Sans (bold, rounded). Body = Inter.
- **Shape**: large radius (rounded-2xl), chunky shadows, soft gradients.
- **Motion**: Framer Motion for streak flames, XP pops, score ring fill, task-complete confetti, page transitions.
- All colors via semantic tokens — no raw hex in components.

## Information architecture

```
/                       Landing
/login  /signup         Auth (email+password, Google)
/onboarding             Wizard (gated — only if no business yet)
/_authenticated/
  app                   Overview (dashboard home)
  app/score             Growth Score deep-dive
  app/tasks             Weekly Tasks (the core loop)
  app/gbp               Google Business Profile module
  app/reviews           Review management
  app/coach             AI Growth Coach (chat)
  app/settings          Profile, business, sign out
```

Locked/coming-soon nav items shown but disabled: Competitors, Rankings, Citations, AI Content, Website SEO, Reports, Academy. This signals roadmap without faking depth.

## Landing page

Single route, sectioned:
1. Hero — headline "Rank higher on Google Maps, one task at a time." Sub, dual CTA, animated dashboard mock.
2. Social-proof strip (logos placeholder).
3. "How it works" — 3 steps with illustrations.
4. Feature grid — Growth Score, Weekly Tasks, GBP Optimizer, Review Engine, AI Coach.
5. Comparison table vs generic SEO tools.
6. Testimonials (placeholder).
7. FAQ (accordion).
8. Final CTA + footer.

SEO: per-route `head()` with title/description/og, JSON-LD SoftwareApplication, single H1, semantic sections.

## Onboarding wizard (5 steps)

Multi-step form with progress bar and Framer transitions.

1. Business name + category (dentist, salon, plumber, etc. — preset list with "Other")
2. Location: city, country, service area
3. Web presence: website URL, GBP URL
4. Snapshot: review count, average rating, photo count, posting frequency, years in business
5. Goals: pick up to 3 (more reviews, more calls, beat competitor X, rank for keyword Y…)

On submit: write `businesses` row, run scoring function, generate first weekly task batch via AI, redirect to `/app`.

## Growth Score (out of 100)

Deterministic local scoring (no external APIs). Weighted factors using onboarding data:

| Factor | Weight |
|---|---|
| Review count | 15 |
| Avg rating | 15 |
| Photo count | 10 |
| Posting frequency | 10 |
| Profile completeness | 15 |
| Service/keyword coverage | 10 |
| Website presence | 10 |
| NAP consistency (self-reported) | 5 |
| Description quality (AI-graded) | 10 |

UI: large animated radial score ring, factor breakdown cards with progress bars, "biggest wins available" list (top 3 lowest-scoring factors with recommended tasks).

## Weekly Tasks — the core loop

This is the product. Everything else supports it.

- AI generates 5–7 tasks per week, scoped to the business's weakest score factors.
- Each task: title, why it matters (AI), priority (P1/P2/P3), impact (+pts to score), difficulty (1–3), estimated minutes, step-by-step tutorial, status.
- Completing a task: confetti + XP gain + score recalculation + streak update.
- Streak counter (days active), level (every 500 XP), badge shelf (First Review Reply, 7-Day Streak, Score 70+, etc.).
- Weekly reset every Monday; missed tasks roll over with reduced XP.
- Empty state encourages "Generate this week's plan."

## GBP module

Self-audit + AI generation (no GBP API).

- Profile completeness checklist (categories, services, hours, attributes, description, photos, posts, FAQs).
- AI tools: rewrite business description, generate 4 GBP posts, generate 10 service descriptions, generate 8 FAQs — all with local keyword insertion and tone selector (Friendly / Professional / Bold).
- Posting calendar: drag onto week, mark posted.

## Reviews module

- Review request generator: WhatsApp link, SMS text, email template, branded QR code (downloadable PNG) pointing to GBP review URL.
- AI review-reply generator: paste review text → 3 reply variants by tone, with negative-review de-escalation mode.
- Self-reported review tracker (count, avg rating, last 5 entries) feeding score.

## AI Growth Coach

Persistent chat (right-side drawer + dedicated page). Uses Vercel AI SDK `useChat` → server route `/api/chat` → Lovable AI Gateway. System prompt loaded with the business's profile + score + open tasks so replies are contextual ("You have 3 P1 tasks open this week; finish the photo upload first — it's worth +6 points"). One-conversation, DB-persisted history.

## Database (Lovable Cloud)

```
profiles            id (=auth.uid), display_name, avatar_url, created_at
user_roles          id, user_id, role(app_role enum)        -- separate table per security rules
businesses          id, owner_id, name, category, city, country, website,
                    gbp_url, review_count, avg_rating, photo_count,
                    posting_freq, years_in_business, goals jsonb, created_at
score_snapshots     id, business_id, score, factors jsonb, created_at
tasks               id, business_id, week_start, title, why, priority,
                    impact_points, difficulty, est_minutes, tutorial_md,
                    status, completed_at
xp_events           id, business_id, source, amount, created_at
badges              id, business_id, code, earned_at
review_entries      id, business_id, rating, text, replied, reply_text, created_at
ai_generations      id, business_id, kind, input jsonb, output text, created_at
chat_messages       id, business_id, role, content, parts jsonb, created_at
```

RLS on every table: owner-only via `business_id → owner_id = auth.uid()`. Roles in separate `user_roles` table with `has_role()` security-definer function.

## Server functions / routes

- `createServerFn` (auth-protected): `getOverview`, `getTasks`, `completeTask`, `regenerateWeeklyTasks`, `recomputeScore`, `generateGbpContent`, `generateReviewReply`, `logReview`.
- Server route `/api/chat` for AI Coach streaming via Vercel AI SDK.
- Public route `/api/health` only.

## Component inventory (new)

`AppShell`, `AppSidebar`, `Topbar`, `ScoreRing`, `FactorBar`, `TaskCard`, `TaskTutorialSheet`, `XPBadge`, `StreakFlame`, `LevelMeter`, `BadgeShelf`, `OnboardingWizard` (+ 5 step components), `GbpChecklist`, `GbpContentStudio`, `PostingCalendar`, `ReviewRequestStudio`, `QrPreview`, `ReplyGenerator`, `CoachChat`, plus marketing sections (`Hero`, `HowItWorks`, `FeatureGrid`, `ComparisonTable`, `Faq`, `Footer`).

## What v1 explicitly does NOT include

Rank tracking, citations, multi-location, white-label, billing/Stripe, PDF reports, Academy content, real GBP/Maps API sync, competitor scraping. Sidebar entries exist as "Coming soon" so the roadmap is visible but nothing is faked.

## Build order

1. Enable Lovable Cloud + auth (email/password + Google).
2. DB schema + RLS + roles.
3. Design tokens + AppShell + sidebar + protected layout.
4. Landing page.
5. Auth pages + onboarding wizard.
6. Score engine + Overview + Score page.
7. Weekly Tasks engine (AI generation + completion + XP/streak/badges).
8. GBP module (checklist + AI content studio).
9. Reviews module (templates + QR + AI reply).
10. AI Coach chat.
11. Polish: empty states, loading skeletons, motion, mobile pass, SEO meta on every route.
